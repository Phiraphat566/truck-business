
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model Employee
 * 
 */
export type Employee = $Result.DefaultSelection<Prisma.$EmployeePayload>
/**
 * Model Attendance
 * 
 */
export type Attendance = $Result.DefaultSelection<Prisma.$AttendancePayload>
/**
 * Model JobAssignment
 * 
 */
export type JobAssignment = $Result.DefaultSelection<Prisma.$JobAssignmentPayload>
/**
 * Model Trip
 * 
 */
export type Trip = $Result.DefaultSelection<Prisma.$TripPayload>
/**
 * Model TravelCost
 * 
 */
export type TravelCost = $Result.DefaultSelection<Prisma.$TravelCostPayload>
/**
 * Model MonthlySummary
 * 
 */
export type MonthlySummary = $Result.DefaultSelection<Prisma.$MonthlySummaryPayload>

/**
 * ##  Prisma Client ʲˢ
 * 
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Employees
 * const employees = await prisma.employee.findMany()
 * ```
 *
 * 
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   * 
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Employees
   * const employees = await prisma.employee.findMany()
   * ```
   *
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): void;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb, ExtArgs>

      /**
   * `prisma.employee`: Exposes CRUD operations for the **Employee** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Employees
    * const employees = await prisma.employee.findMany()
    * ```
    */
  get employee(): Prisma.EmployeeDelegate<ExtArgs>;

  /**
   * `prisma.attendance`: Exposes CRUD operations for the **Attendance** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Attendances
    * const attendances = await prisma.attendance.findMany()
    * ```
    */
  get attendance(): Prisma.AttendanceDelegate<ExtArgs>;

  /**
   * `prisma.jobAssignment`: Exposes CRUD operations for the **JobAssignment** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more JobAssignments
    * const jobAssignments = await prisma.jobAssignment.findMany()
    * ```
    */
  get jobAssignment(): Prisma.JobAssignmentDelegate<ExtArgs>;

  /**
   * `prisma.trip`: Exposes CRUD operations for the **Trip** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Trips
    * const trips = await prisma.trip.findMany()
    * ```
    */
  get trip(): Prisma.TripDelegate<ExtArgs>;

  /**
   * `prisma.travelCost`: Exposes CRUD operations for the **TravelCost** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more TravelCosts
    * const travelCosts = await prisma.travelCost.findMany()
    * ```
    */
  get travelCost(): Prisma.TravelCostDelegate<ExtArgs>;

  /**
   * `prisma.monthlySummary`: Exposes CRUD operations for the **MonthlySummary** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more MonthlySummaries
    * const monthlySummaries = await prisma.monthlySummary.findMany()
    * ```
    */
  get monthlySummary(): Prisma.MonthlySummaryDelegate<ExtArgs>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError
  export import NotFoundError = runtime.NotFoundError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics 
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 5.22.0
   * Query Engine version: 605197351a3c8bdd595af2d2a9bc3025bca48ea2
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion 

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? K : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    Employee: 'Employee',
    Attendance: 'Attendance',
    JobAssignment: 'JobAssignment',
    Trip: 'Trip',
    TravelCost: 'TravelCost',
    MonthlySummary: 'MonthlySummary'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb extends $Utils.Fn<{extArgs: $Extensions.InternalArgs, clientOptions: PrismaClientOptions }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], this['params']['clientOptions']>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, ClientOptions = {}> = {
    meta: {
      modelProps: "employee" | "attendance" | "jobAssignment" | "trip" | "travelCost" | "monthlySummary"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      Employee: {
        payload: Prisma.$EmployeePayload<ExtArgs>
        fields: Prisma.EmployeeFieldRefs
        operations: {
          findUnique: {
            args: Prisma.EmployeeFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.EmployeeFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          findFirst: {
            args: Prisma.EmployeeFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.EmployeeFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          findMany: {
            args: Prisma.EmployeeFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>[]
          }
          create: {
            args: Prisma.EmployeeCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          createMany: {
            args: Prisma.EmployeeCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.EmployeeDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          update: {
            args: Prisma.EmployeeUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          deleteMany: {
            args: Prisma.EmployeeDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.EmployeeUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.EmployeeUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          aggregate: {
            args: Prisma.EmployeeAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEmployee>
          }
          groupBy: {
            args: Prisma.EmployeeGroupByArgs<ExtArgs>
            result: $Utils.Optional<EmployeeGroupByOutputType>[]
          }
          count: {
            args: Prisma.EmployeeCountArgs<ExtArgs>
            result: $Utils.Optional<EmployeeCountAggregateOutputType> | number
          }
        }
      }
      Attendance: {
        payload: Prisma.$AttendancePayload<ExtArgs>
        fields: Prisma.AttendanceFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AttendanceFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AttendancePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AttendanceFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AttendancePayload>
          }
          findFirst: {
            args: Prisma.AttendanceFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AttendancePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AttendanceFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AttendancePayload>
          }
          findMany: {
            args: Prisma.AttendanceFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AttendancePayload>[]
          }
          create: {
            args: Prisma.AttendanceCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AttendancePayload>
          }
          createMany: {
            args: Prisma.AttendanceCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.AttendanceDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AttendancePayload>
          }
          update: {
            args: Prisma.AttendanceUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AttendancePayload>
          }
          deleteMany: {
            args: Prisma.AttendanceDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AttendanceUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.AttendanceUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AttendancePayload>
          }
          aggregate: {
            args: Prisma.AttendanceAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAttendance>
          }
          groupBy: {
            args: Prisma.AttendanceGroupByArgs<ExtArgs>
            result: $Utils.Optional<AttendanceGroupByOutputType>[]
          }
          count: {
            args: Prisma.AttendanceCountArgs<ExtArgs>
            result: $Utils.Optional<AttendanceCountAggregateOutputType> | number
          }
        }
      }
      JobAssignment: {
        payload: Prisma.$JobAssignmentPayload<ExtArgs>
        fields: Prisma.JobAssignmentFieldRefs
        operations: {
          findUnique: {
            args: Prisma.JobAssignmentFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$JobAssignmentPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.JobAssignmentFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$JobAssignmentPayload>
          }
          findFirst: {
            args: Prisma.JobAssignmentFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$JobAssignmentPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.JobAssignmentFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$JobAssignmentPayload>
          }
          findMany: {
            args: Prisma.JobAssignmentFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$JobAssignmentPayload>[]
          }
          create: {
            args: Prisma.JobAssignmentCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$JobAssignmentPayload>
          }
          createMany: {
            args: Prisma.JobAssignmentCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.JobAssignmentDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$JobAssignmentPayload>
          }
          update: {
            args: Prisma.JobAssignmentUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$JobAssignmentPayload>
          }
          deleteMany: {
            args: Prisma.JobAssignmentDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.JobAssignmentUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.JobAssignmentUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$JobAssignmentPayload>
          }
          aggregate: {
            args: Prisma.JobAssignmentAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateJobAssignment>
          }
          groupBy: {
            args: Prisma.JobAssignmentGroupByArgs<ExtArgs>
            result: $Utils.Optional<JobAssignmentGroupByOutputType>[]
          }
          count: {
            args: Prisma.JobAssignmentCountArgs<ExtArgs>
            result: $Utils.Optional<JobAssignmentCountAggregateOutputType> | number
          }
        }
      }
      Trip: {
        payload: Prisma.$TripPayload<ExtArgs>
        fields: Prisma.TripFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TripFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TripPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TripFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TripPayload>
          }
          findFirst: {
            args: Prisma.TripFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TripPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TripFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TripPayload>
          }
          findMany: {
            args: Prisma.TripFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TripPayload>[]
          }
          create: {
            args: Prisma.TripCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TripPayload>
          }
          createMany: {
            args: Prisma.TripCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.TripDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TripPayload>
          }
          update: {
            args: Prisma.TripUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TripPayload>
          }
          deleteMany: {
            args: Prisma.TripDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TripUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.TripUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TripPayload>
          }
          aggregate: {
            args: Prisma.TripAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTrip>
          }
          groupBy: {
            args: Prisma.TripGroupByArgs<ExtArgs>
            result: $Utils.Optional<TripGroupByOutputType>[]
          }
          count: {
            args: Prisma.TripCountArgs<ExtArgs>
            result: $Utils.Optional<TripCountAggregateOutputType> | number
          }
        }
      }
      TravelCost: {
        payload: Prisma.$TravelCostPayload<ExtArgs>
        fields: Prisma.TravelCostFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TravelCostFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TravelCostPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TravelCostFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TravelCostPayload>
          }
          findFirst: {
            args: Prisma.TravelCostFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TravelCostPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TravelCostFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TravelCostPayload>
          }
          findMany: {
            args: Prisma.TravelCostFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TravelCostPayload>[]
          }
          create: {
            args: Prisma.TravelCostCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TravelCostPayload>
          }
          createMany: {
            args: Prisma.TravelCostCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.TravelCostDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TravelCostPayload>
          }
          update: {
            args: Prisma.TravelCostUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TravelCostPayload>
          }
          deleteMany: {
            args: Prisma.TravelCostDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TravelCostUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.TravelCostUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TravelCostPayload>
          }
          aggregate: {
            args: Prisma.TravelCostAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTravelCost>
          }
          groupBy: {
            args: Prisma.TravelCostGroupByArgs<ExtArgs>
            result: $Utils.Optional<TravelCostGroupByOutputType>[]
          }
          count: {
            args: Prisma.TravelCostCountArgs<ExtArgs>
            result: $Utils.Optional<TravelCostCountAggregateOutputType> | number
          }
        }
      }
      MonthlySummary: {
        payload: Prisma.$MonthlySummaryPayload<ExtArgs>
        fields: Prisma.MonthlySummaryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MonthlySummaryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MonthlySummaryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MonthlySummaryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MonthlySummaryPayload>
          }
          findFirst: {
            args: Prisma.MonthlySummaryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MonthlySummaryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MonthlySummaryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MonthlySummaryPayload>
          }
          findMany: {
            args: Prisma.MonthlySummaryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MonthlySummaryPayload>[]
          }
          create: {
            args: Prisma.MonthlySummaryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MonthlySummaryPayload>
          }
          createMany: {
            args: Prisma.MonthlySummaryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.MonthlySummaryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MonthlySummaryPayload>
          }
          update: {
            args: Prisma.MonthlySummaryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MonthlySummaryPayload>
          }
          deleteMany: {
            args: Prisma.MonthlySummaryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MonthlySummaryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.MonthlySummaryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MonthlySummaryPayload>
          }
          aggregate: {
            args: Prisma.MonthlySummaryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMonthlySummary>
          }
          groupBy: {
            args: Prisma.MonthlySummaryGroupByArgs<ExtArgs>
            result: $Utils.Optional<MonthlySummaryGroupByOutputType>[]
          }
          count: {
            args: Prisma.MonthlySummaryCountArgs<ExtArgs>
            result: $Utils.Optional<MonthlySummaryCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
  }


  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type EmployeeCountOutputType
   */

  export type EmployeeCountOutputType = {
    attendances: number
    jobAssignments: number
    monthlySummaries: number
  }

  export type EmployeeCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    attendances?: boolean | EmployeeCountOutputTypeCountAttendancesArgs
    jobAssignments?: boolean | EmployeeCountOutputTypeCountJobAssignmentsArgs
    monthlySummaries?: boolean | EmployeeCountOutputTypeCountMonthlySummariesArgs
  }

  // Custom InputTypes
  /**
   * EmployeeCountOutputType without action
   */
  export type EmployeeCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmployeeCountOutputType
     */
    select?: EmployeeCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * EmployeeCountOutputType without action
   */
  export type EmployeeCountOutputTypeCountAttendancesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AttendanceWhereInput
  }

  /**
   * EmployeeCountOutputType without action
   */
  export type EmployeeCountOutputTypeCountJobAssignmentsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: JobAssignmentWhereInput
  }

  /**
   * EmployeeCountOutputType without action
   */
  export type EmployeeCountOutputTypeCountMonthlySummariesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MonthlySummaryWhereInput
  }


  /**
   * Count Type JobAssignmentCountOutputType
   */

  export type JobAssignmentCountOutputType = {
    trips: number
  }

  export type JobAssignmentCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    trips?: boolean | JobAssignmentCountOutputTypeCountTripsArgs
  }

  // Custom InputTypes
  /**
   * JobAssignmentCountOutputType without action
   */
  export type JobAssignmentCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignmentCountOutputType
     */
    select?: JobAssignmentCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * JobAssignmentCountOutputType without action
   */
  export type JobAssignmentCountOutputTypeCountTripsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TripWhereInput
  }


  /**
   * Models
   */

  /**
   * Model Employee
   */

  export type AggregateEmployee = {
    _count: EmployeeCountAggregateOutputType | null
    _min: EmployeeMinAggregateOutputType | null
    _max: EmployeeMaxAggregateOutputType | null
  }

  export type EmployeeMinAggregateOutputType = {
    id: string | null
    name: string | null
    position: string | null
    phone: string | null
  }

  export type EmployeeMaxAggregateOutputType = {
    id: string | null
    name: string | null
    position: string | null
    phone: string | null
  }

  export type EmployeeCountAggregateOutputType = {
    id: number
    name: number
    position: number
    phone: number
    _all: number
  }


  export type EmployeeMinAggregateInputType = {
    id?: true
    name?: true
    position?: true
    phone?: true
  }

  export type EmployeeMaxAggregateInputType = {
    id?: true
    name?: true
    position?: true
    phone?: true
  }

  export type EmployeeCountAggregateInputType = {
    id?: true
    name?: true
    position?: true
    phone?: true
    _all?: true
  }

  export type EmployeeAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Employee to aggregate.
     */
    where?: EmployeeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Employees to fetch.
     */
    orderBy?: EmployeeOrderByWithRelationInput | EmployeeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: EmployeeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Employees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Employees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Employees
    **/
    _count?: true | EmployeeCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EmployeeMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EmployeeMaxAggregateInputType
  }

  export type GetEmployeeAggregateType<T extends EmployeeAggregateArgs> = {
        [P in keyof T & keyof AggregateEmployee]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEmployee[P]>
      : GetScalarType<T[P], AggregateEmployee[P]>
  }




  export type EmployeeGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EmployeeWhereInput
    orderBy?: EmployeeOrderByWithAggregationInput | EmployeeOrderByWithAggregationInput[]
    by: EmployeeScalarFieldEnum[] | EmployeeScalarFieldEnum
    having?: EmployeeScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EmployeeCountAggregateInputType | true
    _min?: EmployeeMinAggregateInputType
    _max?: EmployeeMaxAggregateInputType
  }

  export type EmployeeGroupByOutputType = {
    id: string
    name: string
    position: string
    phone: string
    _count: EmployeeCountAggregateOutputType | null
    _min: EmployeeMinAggregateOutputType | null
    _max: EmployeeMaxAggregateOutputType | null
  }

  type GetEmployeeGroupByPayload<T extends EmployeeGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<EmployeeGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EmployeeGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EmployeeGroupByOutputType[P]>
            : GetScalarType<T[P], EmployeeGroupByOutputType[P]>
        }
      >
    >


  export type EmployeeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    position?: boolean
    phone?: boolean
    attendances?: boolean | Employee$attendancesArgs<ExtArgs>
    jobAssignments?: boolean | Employee$jobAssignmentsArgs<ExtArgs>
    monthlySummaries?: boolean | Employee$monthlySummariesArgs<ExtArgs>
    _count?: boolean | EmployeeCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["employee"]>


  export type EmployeeSelectScalar = {
    id?: boolean
    name?: boolean
    position?: boolean
    phone?: boolean
  }

  export type EmployeeInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    attendances?: boolean | Employee$attendancesArgs<ExtArgs>
    jobAssignments?: boolean | Employee$jobAssignmentsArgs<ExtArgs>
    monthlySummaries?: boolean | Employee$monthlySummariesArgs<ExtArgs>
    _count?: boolean | EmployeeCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $EmployeePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Employee"
    objects: {
      attendances: Prisma.$AttendancePayload<ExtArgs>[]
      jobAssignments: Prisma.$JobAssignmentPayload<ExtArgs>[]
      monthlySummaries: Prisma.$MonthlySummaryPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      position: string
      phone: string
    }, ExtArgs["result"]["employee"]>
    composites: {}
  }

  type EmployeeGetPayload<S extends boolean | null | undefined | EmployeeDefaultArgs> = $Result.GetResult<Prisma.$EmployeePayload, S>

  type EmployeeCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<EmployeeFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: EmployeeCountAggregateInputType | true
    }

  export interface EmployeeDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Employee'], meta: { name: 'Employee' } }
    /**
     * Find zero or one Employee that matches the filter.
     * @param {EmployeeFindUniqueArgs} args - Arguments to find a Employee
     * @example
     * // Get one Employee
     * const employee = await prisma.employee.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends EmployeeFindUniqueArgs>(args: SelectSubset<T, EmployeeFindUniqueArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findUnique"> | null, null, ExtArgs>

    /**
     * Find one Employee that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {EmployeeFindUniqueOrThrowArgs} args - Arguments to find a Employee
     * @example
     * // Get one Employee
     * const employee = await prisma.employee.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends EmployeeFindUniqueOrThrowArgs>(args: SelectSubset<T, EmployeeFindUniqueOrThrowArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findUniqueOrThrow">, never, ExtArgs>

    /**
     * Find the first Employee that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeFindFirstArgs} args - Arguments to find a Employee
     * @example
     * // Get one Employee
     * const employee = await prisma.employee.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends EmployeeFindFirstArgs>(args?: SelectSubset<T, EmployeeFindFirstArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findFirst"> | null, null, ExtArgs>

    /**
     * Find the first Employee that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeFindFirstOrThrowArgs} args - Arguments to find a Employee
     * @example
     * // Get one Employee
     * const employee = await prisma.employee.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends EmployeeFindFirstOrThrowArgs>(args?: SelectSubset<T, EmployeeFindFirstOrThrowArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findFirstOrThrow">, never, ExtArgs>

    /**
     * Find zero or more Employees that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Employees
     * const employees = await prisma.employee.findMany()
     * 
     * // Get first 10 Employees
     * const employees = await prisma.employee.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const employeeWithIdOnly = await prisma.employee.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends EmployeeFindManyArgs>(args?: SelectSubset<T, EmployeeFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findMany">>

    /**
     * Create a Employee.
     * @param {EmployeeCreateArgs} args - Arguments to create a Employee.
     * @example
     * // Create one Employee
     * const Employee = await prisma.employee.create({
     *   data: {
     *     // ... data to create a Employee
     *   }
     * })
     * 
     */
    create<T extends EmployeeCreateArgs>(args: SelectSubset<T, EmployeeCreateArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "create">, never, ExtArgs>

    /**
     * Create many Employees.
     * @param {EmployeeCreateManyArgs} args - Arguments to create many Employees.
     * @example
     * // Create many Employees
     * const employee = await prisma.employee.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends EmployeeCreateManyArgs>(args?: SelectSubset<T, EmployeeCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Employee.
     * @param {EmployeeDeleteArgs} args - Arguments to delete one Employee.
     * @example
     * // Delete one Employee
     * const Employee = await prisma.employee.delete({
     *   where: {
     *     // ... filter to delete one Employee
     *   }
     * })
     * 
     */
    delete<T extends EmployeeDeleteArgs>(args: SelectSubset<T, EmployeeDeleteArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "delete">, never, ExtArgs>

    /**
     * Update one Employee.
     * @param {EmployeeUpdateArgs} args - Arguments to update one Employee.
     * @example
     * // Update one Employee
     * const employee = await prisma.employee.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends EmployeeUpdateArgs>(args: SelectSubset<T, EmployeeUpdateArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "update">, never, ExtArgs>

    /**
     * Delete zero or more Employees.
     * @param {EmployeeDeleteManyArgs} args - Arguments to filter Employees to delete.
     * @example
     * // Delete a few Employees
     * const { count } = await prisma.employee.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends EmployeeDeleteManyArgs>(args?: SelectSubset<T, EmployeeDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Employees.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Employees
     * const employee = await prisma.employee.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends EmployeeUpdateManyArgs>(args: SelectSubset<T, EmployeeUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Employee.
     * @param {EmployeeUpsertArgs} args - Arguments to update or create a Employee.
     * @example
     * // Update or create a Employee
     * const employee = await prisma.employee.upsert({
     *   create: {
     *     // ... data to create a Employee
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Employee we want to update
     *   }
     * })
     */
    upsert<T extends EmployeeUpsertArgs>(args: SelectSubset<T, EmployeeUpsertArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "upsert">, never, ExtArgs>


    /**
     * Count the number of Employees.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeCountArgs} args - Arguments to filter Employees to count.
     * @example
     * // Count the number of Employees
     * const count = await prisma.employee.count({
     *   where: {
     *     // ... the filter for the Employees we want to count
     *   }
     * })
    **/
    count<T extends EmployeeCountArgs>(
      args?: Subset<T, EmployeeCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EmployeeCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Employee.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EmployeeAggregateArgs>(args: Subset<T, EmployeeAggregateArgs>): Prisma.PrismaPromise<GetEmployeeAggregateType<T>>

    /**
     * Group by Employee.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends EmployeeGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: EmployeeGroupByArgs['orderBy'] }
        : { orderBy?: EmployeeGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, EmployeeGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEmployeeGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Employee model
   */
  readonly fields: EmployeeFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Employee.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__EmployeeClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    attendances<T extends Employee$attendancesArgs<ExtArgs> = {}>(args?: Subset<T, Employee$attendancesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AttendancePayload<ExtArgs>, T, "findMany"> | Null>
    jobAssignments<T extends Employee$jobAssignmentsArgs<ExtArgs> = {}>(args?: Subset<T, Employee$jobAssignmentsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "findMany"> | Null>
    monthlySummaries<T extends Employee$monthlySummariesArgs<ExtArgs> = {}>(args?: Subset<T, Employee$monthlySummariesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MonthlySummaryPayload<ExtArgs>, T, "findMany"> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Employee model
   */ 
  interface EmployeeFieldRefs {
    readonly id: FieldRef<"Employee", 'String'>
    readonly name: FieldRef<"Employee", 'String'>
    readonly position: FieldRef<"Employee", 'String'>
    readonly phone: FieldRef<"Employee", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Employee findUnique
   */
  export type EmployeeFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter, which Employee to fetch.
     */
    where: EmployeeWhereUniqueInput
  }

  /**
   * Employee findUniqueOrThrow
   */
  export type EmployeeFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter, which Employee to fetch.
     */
    where: EmployeeWhereUniqueInput
  }

  /**
   * Employee findFirst
   */
  export type EmployeeFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter, which Employee to fetch.
     */
    where?: EmployeeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Employees to fetch.
     */
    orderBy?: EmployeeOrderByWithRelationInput | EmployeeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Employees.
     */
    cursor?: EmployeeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Employees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Employees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Employees.
     */
    distinct?: EmployeeScalarFieldEnum | EmployeeScalarFieldEnum[]
  }

  /**
   * Employee findFirstOrThrow
   */
  export type EmployeeFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter, which Employee to fetch.
     */
    where?: EmployeeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Employees to fetch.
     */
    orderBy?: EmployeeOrderByWithRelationInput | EmployeeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Employees.
     */
    cursor?: EmployeeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Employees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Employees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Employees.
     */
    distinct?: EmployeeScalarFieldEnum | EmployeeScalarFieldEnum[]
  }

  /**
   * Employee findMany
   */
  export type EmployeeFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter, which Employees to fetch.
     */
    where?: EmployeeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Employees to fetch.
     */
    orderBy?: EmployeeOrderByWithRelationInput | EmployeeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Employees.
     */
    cursor?: EmployeeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Employees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Employees.
     */
    skip?: number
    distinct?: EmployeeScalarFieldEnum | EmployeeScalarFieldEnum[]
  }

  /**
   * Employee create
   */
  export type EmployeeCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * The data needed to create a Employee.
     */
    data: XOR<EmployeeCreateInput, EmployeeUncheckedCreateInput>
  }

  /**
   * Employee createMany
   */
  export type EmployeeCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Employees.
     */
    data: EmployeeCreateManyInput | EmployeeCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Employee update
   */
  export type EmployeeUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * The data needed to update a Employee.
     */
    data: XOR<EmployeeUpdateInput, EmployeeUncheckedUpdateInput>
    /**
     * Choose, which Employee to update.
     */
    where: EmployeeWhereUniqueInput
  }

  /**
   * Employee updateMany
   */
  export type EmployeeUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Employees.
     */
    data: XOR<EmployeeUpdateManyMutationInput, EmployeeUncheckedUpdateManyInput>
    /**
     * Filter which Employees to update
     */
    where?: EmployeeWhereInput
  }

  /**
   * Employee upsert
   */
  export type EmployeeUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * The filter to search for the Employee to update in case it exists.
     */
    where: EmployeeWhereUniqueInput
    /**
     * In case the Employee found by the `where` argument doesn't exist, create a new Employee with this data.
     */
    create: XOR<EmployeeCreateInput, EmployeeUncheckedCreateInput>
    /**
     * In case the Employee was found with the provided `where` argument, update it with this data.
     */
    update: XOR<EmployeeUpdateInput, EmployeeUncheckedUpdateInput>
  }

  /**
   * Employee delete
   */
  export type EmployeeDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter which Employee to delete.
     */
    where: EmployeeWhereUniqueInput
  }

  /**
   * Employee deleteMany
   */
  export type EmployeeDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Employees to delete
     */
    where?: EmployeeWhereInput
  }

  /**
   * Employee.attendances
   */
  export type Employee$attendancesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
    where?: AttendanceWhereInput
    orderBy?: AttendanceOrderByWithRelationInput | AttendanceOrderByWithRelationInput[]
    cursor?: AttendanceWhereUniqueInput
    take?: number
    skip?: number
    distinct?: AttendanceScalarFieldEnum | AttendanceScalarFieldEnum[]
  }

  /**
   * Employee.jobAssignments
   */
  export type Employee$jobAssignmentsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
    where?: JobAssignmentWhereInput
    orderBy?: JobAssignmentOrderByWithRelationInput | JobAssignmentOrderByWithRelationInput[]
    cursor?: JobAssignmentWhereUniqueInput
    take?: number
    skip?: number
    distinct?: JobAssignmentScalarFieldEnum | JobAssignmentScalarFieldEnum[]
  }

  /**
   * Employee.monthlySummaries
   */
  export type Employee$monthlySummariesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
    where?: MonthlySummaryWhereInput
    orderBy?: MonthlySummaryOrderByWithRelationInput | MonthlySummaryOrderByWithRelationInput[]
    cursor?: MonthlySummaryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MonthlySummaryScalarFieldEnum | MonthlySummaryScalarFieldEnum[]
  }

  /**
   * Employee without action
   */
  export type EmployeeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
  }


  /**
   * Model Attendance
   */

  export type AggregateAttendance = {
    _count: AttendanceCountAggregateOutputType | null
    _min: AttendanceMinAggregateOutputType | null
    _max: AttendanceMaxAggregateOutputType | null
  }

  export type AttendanceMinAggregateOutputType = {
    id: string | null
    employeeId: string | null
    checkIn: Date | null
    checkOut: Date | null
    date: Date | null
  }

  export type AttendanceMaxAggregateOutputType = {
    id: string | null
    employeeId: string | null
    checkIn: Date | null
    checkOut: Date | null
    date: Date | null
  }

  export type AttendanceCountAggregateOutputType = {
    id: number
    employeeId: number
    checkIn: number
    checkOut: number
    date: number
    _all: number
  }


  export type AttendanceMinAggregateInputType = {
    id?: true
    employeeId?: true
    checkIn?: true
    checkOut?: true
    date?: true
  }

  export type AttendanceMaxAggregateInputType = {
    id?: true
    employeeId?: true
    checkIn?: true
    checkOut?: true
    date?: true
  }

  export type AttendanceCountAggregateInputType = {
    id?: true
    employeeId?: true
    checkIn?: true
    checkOut?: true
    date?: true
    _all?: true
  }

  export type AttendanceAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Attendance to aggregate.
     */
    where?: AttendanceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Attendances to fetch.
     */
    orderBy?: AttendanceOrderByWithRelationInput | AttendanceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AttendanceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Attendances from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Attendances.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Attendances
    **/
    _count?: true | AttendanceCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AttendanceMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AttendanceMaxAggregateInputType
  }

  export type GetAttendanceAggregateType<T extends AttendanceAggregateArgs> = {
        [P in keyof T & keyof AggregateAttendance]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAttendance[P]>
      : GetScalarType<T[P], AggregateAttendance[P]>
  }




  export type AttendanceGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AttendanceWhereInput
    orderBy?: AttendanceOrderByWithAggregationInput | AttendanceOrderByWithAggregationInput[]
    by: AttendanceScalarFieldEnum[] | AttendanceScalarFieldEnum
    having?: AttendanceScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AttendanceCountAggregateInputType | true
    _min?: AttendanceMinAggregateInputType
    _max?: AttendanceMaxAggregateInputType
  }

  export type AttendanceGroupByOutputType = {
    id: string
    employeeId: string
    checkIn: Date
    checkOut: Date
    date: Date
    _count: AttendanceCountAggregateOutputType | null
    _min: AttendanceMinAggregateOutputType | null
    _max: AttendanceMaxAggregateOutputType | null
  }

  type GetAttendanceGroupByPayload<T extends AttendanceGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AttendanceGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AttendanceGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AttendanceGroupByOutputType[P]>
            : GetScalarType<T[P], AttendanceGroupByOutputType[P]>
        }
      >
    >


  export type AttendanceSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    employeeId?: boolean
    checkIn?: boolean
    checkOut?: boolean
    date?: boolean
    employee?: boolean | EmployeeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["attendance"]>


  export type AttendanceSelectScalar = {
    id?: boolean
    employeeId?: boolean
    checkIn?: boolean
    checkOut?: boolean
    date?: boolean
  }

  export type AttendanceInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    employee?: boolean | EmployeeDefaultArgs<ExtArgs>
  }

  export type $AttendancePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Attendance"
    objects: {
      employee: Prisma.$EmployeePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      employeeId: string
      checkIn: Date
      checkOut: Date
      date: Date
    }, ExtArgs["result"]["attendance"]>
    composites: {}
  }

  type AttendanceGetPayload<S extends boolean | null | undefined | AttendanceDefaultArgs> = $Result.GetResult<Prisma.$AttendancePayload, S>

  type AttendanceCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<AttendanceFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: AttendanceCountAggregateInputType | true
    }

  export interface AttendanceDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Attendance'], meta: { name: 'Attendance' } }
    /**
     * Find zero or one Attendance that matches the filter.
     * @param {AttendanceFindUniqueArgs} args - Arguments to find a Attendance
     * @example
     * // Get one Attendance
     * const attendance = await prisma.attendance.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AttendanceFindUniqueArgs>(args: SelectSubset<T, AttendanceFindUniqueArgs<ExtArgs>>): Prisma__AttendanceClient<$Result.GetResult<Prisma.$AttendancePayload<ExtArgs>, T, "findUnique"> | null, null, ExtArgs>

    /**
     * Find one Attendance that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {AttendanceFindUniqueOrThrowArgs} args - Arguments to find a Attendance
     * @example
     * // Get one Attendance
     * const attendance = await prisma.attendance.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AttendanceFindUniqueOrThrowArgs>(args: SelectSubset<T, AttendanceFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AttendanceClient<$Result.GetResult<Prisma.$AttendancePayload<ExtArgs>, T, "findUniqueOrThrow">, never, ExtArgs>

    /**
     * Find the first Attendance that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AttendanceFindFirstArgs} args - Arguments to find a Attendance
     * @example
     * // Get one Attendance
     * const attendance = await prisma.attendance.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AttendanceFindFirstArgs>(args?: SelectSubset<T, AttendanceFindFirstArgs<ExtArgs>>): Prisma__AttendanceClient<$Result.GetResult<Prisma.$AttendancePayload<ExtArgs>, T, "findFirst"> | null, null, ExtArgs>

    /**
     * Find the first Attendance that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AttendanceFindFirstOrThrowArgs} args - Arguments to find a Attendance
     * @example
     * // Get one Attendance
     * const attendance = await prisma.attendance.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AttendanceFindFirstOrThrowArgs>(args?: SelectSubset<T, AttendanceFindFirstOrThrowArgs<ExtArgs>>): Prisma__AttendanceClient<$Result.GetResult<Prisma.$AttendancePayload<ExtArgs>, T, "findFirstOrThrow">, never, ExtArgs>

    /**
     * Find zero or more Attendances that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AttendanceFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Attendances
     * const attendances = await prisma.attendance.findMany()
     * 
     * // Get first 10 Attendances
     * const attendances = await prisma.attendance.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const attendanceWithIdOnly = await prisma.attendance.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends AttendanceFindManyArgs>(args?: SelectSubset<T, AttendanceFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AttendancePayload<ExtArgs>, T, "findMany">>

    /**
     * Create a Attendance.
     * @param {AttendanceCreateArgs} args - Arguments to create a Attendance.
     * @example
     * // Create one Attendance
     * const Attendance = await prisma.attendance.create({
     *   data: {
     *     // ... data to create a Attendance
     *   }
     * })
     * 
     */
    create<T extends AttendanceCreateArgs>(args: SelectSubset<T, AttendanceCreateArgs<ExtArgs>>): Prisma__AttendanceClient<$Result.GetResult<Prisma.$AttendancePayload<ExtArgs>, T, "create">, never, ExtArgs>

    /**
     * Create many Attendances.
     * @param {AttendanceCreateManyArgs} args - Arguments to create many Attendances.
     * @example
     * // Create many Attendances
     * const attendance = await prisma.attendance.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AttendanceCreateManyArgs>(args?: SelectSubset<T, AttendanceCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Attendance.
     * @param {AttendanceDeleteArgs} args - Arguments to delete one Attendance.
     * @example
     * // Delete one Attendance
     * const Attendance = await prisma.attendance.delete({
     *   where: {
     *     // ... filter to delete one Attendance
     *   }
     * })
     * 
     */
    delete<T extends AttendanceDeleteArgs>(args: SelectSubset<T, AttendanceDeleteArgs<ExtArgs>>): Prisma__AttendanceClient<$Result.GetResult<Prisma.$AttendancePayload<ExtArgs>, T, "delete">, never, ExtArgs>

    /**
     * Update one Attendance.
     * @param {AttendanceUpdateArgs} args - Arguments to update one Attendance.
     * @example
     * // Update one Attendance
     * const attendance = await prisma.attendance.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AttendanceUpdateArgs>(args: SelectSubset<T, AttendanceUpdateArgs<ExtArgs>>): Prisma__AttendanceClient<$Result.GetResult<Prisma.$AttendancePayload<ExtArgs>, T, "update">, never, ExtArgs>

    /**
     * Delete zero or more Attendances.
     * @param {AttendanceDeleteManyArgs} args - Arguments to filter Attendances to delete.
     * @example
     * // Delete a few Attendances
     * const { count } = await prisma.attendance.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AttendanceDeleteManyArgs>(args?: SelectSubset<T, AttendanceDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Attendances.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AttendanceUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Attendances
     * const attendance = await prisma.attendance.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AttendanceUpdateManyArgs>(args: SelectSubset<T, AttendanceUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Attendance.
     * @param {AttendanceUpsertArgs} args - Arguments to update or create a Attendance.
     * @example
     * // Update or create a Attendance
     * const attendance = await prisma.attendance.upsert({
     *   create: {
     *     // ... data to create a Attendance
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Attendance we want to update
     *   }
     * })
     */
    upsert<T extends AttendanceUpsertArgs>(args: SelectSubset<T, AttendanceUpsertArgs<ExtArgs>>): Prisma__AttendanceClient<$Result.GetResult<Prisma.$AttendancePayload<ExtArgs>, T, "upsert">, never, ExtArgs>


    /**
     * Count the number of Attendances.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AttendanceCountArgs} args - Arguments to filter Attendances to count.
     * @example
     * // Count the number of Attendances
     * const count = await prisma.attendance.count({
     *   where: {
     *     // ... the filter for the Attendances we want to count
     *   }
     * })
    **/
    count<T extends AttendanceCountArgs>(
      args?: Subset<T, AttendanceCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AttendanceCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Attendance.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AttendanceAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AttendanceAggregateArgs>(args: Subset<T, AttendanceAggregateArgs>): Prisma.PrismaPromise<GetAttendanceAggregateType<T>>

    /**
     * Group by Attendance.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AttendanceGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AttendanceGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AttendanceGroupByArgs['orderBy'] }
        : { orderBy?: AttendanceGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AttendanceGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAttendanceGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Attendance model
   */
  readonly fields: AttendanceFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Attendance.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AttendanceClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    employee<T extends EmployeeDefaultArgs<ExtArgs> = {}>(args?: Subset<T, EmployeeDefaultArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findUniqueOrThrow"> | Null, Null, ExtArgs>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Attendance model
   */ 
  interface AttendanceFieldRefs {
    readonly id: FieldRef<"Attendance", 'String'>
    readonly employeeId: FieldRef<"Attendance", 'String'>
    readonly checkIn: FieldRef<"Attendance", 'DateTime'>
    readonly checkOut: FieldRef<"Attendance", 'DateTime'>
    readonly date: FieldRef<"Attendance", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Attendance findUnique
   */
  export type AttendanceFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
    /**
     * Filter, which Attendance to fetch.
     */
    where: AttendanceWhereUniqueInput
  }

  /**
   * Attendance findUniqueOrThrow
   */
  export type AttendanceFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
    /**
     * Filter, which Attendance to fetch.
     */
    where: AttendanceWhereUniqueInput
  }

  /**
   * Attendance findFirst
   */
  export type AttendanceFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
    /**
     * Filter, which Attendance to fetch.
     */
    where?: AttendanceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Attendances to fetch.
     */
    orderBy?: AttendanceOrderByWithRelationInput | AttendanceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Attendances.
     */
    cursor?: AttendanceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Attendances from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Attendances.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Attendances.
     */
    distinct?: AttendanceScalarFieldEnum | AttendanceScalarFieldEnum[]
  }

  /**
   * Attendance findFirstOrThrow
   */
  export type AttendanceFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
    /**
     * Filter, which Attendance to fetch.
     */
    where?: AttendanceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Attendances to fetch.
     */
    orderBy?: AttendanceOrderByWithRelationInput | AttendanceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Attendances.
     */
    cursor?: AttendanceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Attendances from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Attendances.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Attendances.
     */
    distinct?: AttendanceScalarFieldEnum | AttendanceScalarFieldEnum[]
  }

  /**
   * Attendance findMany
   */
  export type AttendanceFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
    /**
     * Filter, which Attendances to fetch.
     */
    where?: AttendanceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Attendances to fetch.
     */
    orderBy?: AttendanceOrderByWithRelationInput | AttendanceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Attendances.
     */
    cursor?: AttendanceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Attendances from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Attendances.
     */
    skip?: number
    distinct?: AttendanceScalarFieldEnum | AttendanceScalarFieldEnum[]
  }

  /**
   * Attendance create
   */
  export type AttendanceCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
    /**
     * The data needed to create a Attendance.
     */
    data: XOR<AttendanceCreateInput, AttendanceUncheckedCreateInput>
  }

  /**
   * Attendance createMany
   */
  export type AttendanceCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Attendances.
     */
    data: AttendanceCreateManyInput | AttendanceCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Attendance update
   */
  export type AttendanceUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
    /**
     * The data needed to update a Attendance.
     */
    data: XOR<AttendanceUpdateInput, AttendanceUncheckedUpdateInput>
    /**
     * Choose, which Attendance to update.
     */
    where: AttendanceWhereUniqueInput
  }

  /**
   * Attendance updateMany
   */
  export type AttendanceUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Attendances.
     */
    data: XOR<AttendanceUpdateManyMutationInput, AttendanceUncheckedUpdateManyInput>
    /**
     * Filter which Attendances to update
     */
    where?: AttendanceWhereInput
  }

  /**
   * Attendance upsert
   */
  export type AttendanceUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
    /**
     * The filter to search for the Attendance to update in case it exists.
     */
    where: AttendanceWhereUniqueInput
    /**
     * In case the Attendance found by the `where` argument doesn't exist, create a new Attendance with this data.
     */
    create: XOR<AttendanceCreateInput, AttendanceUncheckedCreateInput>
    /**
     * In case the Attendance was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AttendanceUpdateInput, AttendanceUncheckedUpdateInput>
  }

  /**
   * Attendance delete
   */
  export type AttendanceDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
    /**
     * Filter which Attendance to delete.
     */
    where: AttendanceWhereUniqueInput
  }

  /**
   * Attendance deleteMany
   */
  export type AttendanceDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Attendances to delete
     */
    where?: AttendanceWhereInput
  }

  /**
   * Attendance without action
   */
  export type AttendanceDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Attendance
     */
    select?: AttendanceSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AttendanceInclude<ExtArgs> | null
  }


  /**
   * Model JobAssignment
   */

  export type AggregateJobAssignment = {
    _count: JobAssignmentCountAggregateOutputType | null
    _min: JobAssignmentMinAggregateOutputType | null
    _max: JobAssignmentMaxAggregateOutputType | null
  }

  export type JobAssignmentMinAggregateOutputType = {
    id: string | null
    employeeId: string | null
    description: string | null
    assignedDate: Date | null
    status: string | null
  }

  export type JobAssignmentMaxAggregateOutputType = {
    id: string | null
    employeeId: string | null
    description: string | null
    assignedDate: Date | null
    status: string | null
  }

  export type JobAssignmentCountAggregateOutputType = {
    id: number
    employeeId: number
    description: number
    assignedDate: number
    status: number
    _all: number
  }


  export type JobAssignmentMinAggregateInputType = {
    id?: true
    employeeId?: true
    description?: true
    assignedDate?: true
    status?: true
  }

  export type JobAssignmentMaxAggregateInputType = {
    id?: true
    employeeId?: true
    description?: true
    assignedDate?: true
    status?: true
  }

  export type JobAssignmentCountAggregateInputType = {
    id?: true
    employeeId?: true
    description?: true
    assignedDate?: true
    status?: true
    _all?: true
  }

  export type JobAssignmentAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which JobAssignment to aggregate.
     */
    where?: JobAssignmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of JobAssignments to fetch.
     */
    orderBy?: JobAssignmentOrderByWithRelationInput | JobAssignmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: JobAssignmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` JobAssignments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` JobAssignments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned JobAssignments
    **/
    _count?: true | JobAssignmentCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: JobAssignmentMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: JobAssignmentMaxAggregateInputType
  }

  export type GetJobAssignmentAggregateType<T extends JobAssignmentAggregateArgs> = {
        [P in keyof T & keyof AggregateJobAssignment]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateJobAssignment[P]>
      : GetScalarType<T[P], AggregateJobAssignment[P]>
  }




  export type JobAssignmentGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: JobAssignmentWhereInput
    orderBy?: JobAssignmentOrderByWithAggregationInput | JobAssignmentOrderByWithAggregationInput[]
    by: JobAssignmentScalarFieldEnum[] | JobAssignmentScalarFieldEnum
    having?: JobAssignmentScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: JobAssignmentCountAggregateInputType | true
    _min?: JobAssignmentMinAggregateInputType
    _max?: JobAssignmentMaxAggregateInputType
  }

  export type JobAssignmentGroupByOutputType = {
    id: string
    employeeId: string
    description: string
    assignedDate: Date
    status: string
    _count: JobAssignmentCountAggregateOutputType | null
    _min: JobAssignmentMinAggregateOutputType | null
    _max: JobAssignmentMaxAggregateOutputType | null
  }

  type GetJobAssignmentGroupByPayload<T extends JobAssignmentGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<JobAssignmentGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof JobAssignmentGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], JobAssignmentGroupByOutputType[P]>
            : GetScalarType<T[P], JobAssignmentGroupByOutputType[P]>
        }
      >
    >


  export type JobAssignmentSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    employeeId?: boolean
    description?: boolean
    assignedDate?: boolean
    status?: boolean
    employee?: boolean | EmployeeDefaultArgs<ExtArgs>
    trips?: boolean | JobAssignment$tripsArgs<ExtArgs>
    _count?: boolean | JobAssignmentCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["jobAssignment"]>


  export type JobAssignmentSelectScalar = {
    id?: boolean
    employeeId?: boolean
    description?: boolean
    assignedDate?: boolean
    status?: boolean
  }

  export type JobAssignmentInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    employee?: boolean | EmployeeDefaultArgs<ExtArgs>
    trips?: boolean | JobAssignment$tripsArgs<ExtArgs>
    _count?: boolean | JobAssignmentCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $JobAssignmentPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "JobAssignment"
    objects: {
      employee: Prisma.$EmployeePayload<ExtArgs>
      trips: Prisma.$TripPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      employeeId: string
      description: string
      assignedDate: Date
      status: string
    }, ExtArgs["result"]["jobAssignment"]>
    composites: {}
  }

  type JobAssignmentGetPayload<S extends boolean | null | undefined | JobAssignmentDefaultArgs> = $Result.GetResult<Prisma.$JobAssignmentPayload, S>

  type JobAssignmentCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<JobAssignmentFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: JobAssignmentCountAggregateInputType | true
    }

  export interface JobAssignmentDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['JobAssignment'], meta: { name: 'JobAssignment' } }
    /**
     * Find zero or one JobAssignment that matches the filter.
     * @param {JobAssignmentFindUniqueArgs} args - Arguments to find a JobAssignment
     * @example
     * // Get one JobAssignment
     * const jobAssignment = await prisma.jobAssignment.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends JobAssignmentFindUniqueArgs>(args: SelectSubset<T, JobAssignmentFindUniqueArgs<ExtArgs>>): Prisma__JobAssignmentClient<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "findUnique"> | null, null, ExtArgs>

    /**
     * Find one JobAssignment that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {JobAssignmentFindUniqueOrThrowArgs} args - Arguments to find a JobAssignment
     * @example
     * // Get one JobAssignment
     * const jobAssignment = await prisma.jobAssignment.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends JobAssignmentFindUniqueOrThrowArgs>(args: SelectSubset<T, JobAssignmentFindUniqueOrThrowArgs<ExtArgs>>): Prisma__JobAssignmentClient<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "findUniqueOrThrow">, never, ExtArgs>

    /**
     * Find the first JobAssignment that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {JobAssignmentFindFirstArgs} args - Arguments to find a JobAssignment
     * @example
     * // Get one JobAssignment
     * const jobAssignment = await prisma.jobAssignment.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends JobAssignmentFindFirstArgs>(args?: SelectSubset<T, JobAssignmentFindFirstArgs<ExtArgs>>): Prisma__JobAssignmentClient<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "findFirst"> | null, null, ExtArgs>

    /**
     * Find the first JobAssignment that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {JobAssignmentFindFirstOrThrowArgs} args - Arguments to find a JobAssignment
     * @example
     * // Get one JobAssignment
     * const jobAssignment = await prisma.jobAssignment.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends JobAssignmentFindFirstOrThrowArgs>(args?: SelectSubset<T, JobAssignmentFindFirstOrThrowArgs<ExtArgs>>): Prisma__JobAssignmentClient<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "findFirstOrThrow">, never, ExtArgs>

    /**
     * Find zero or more JobAssignments that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {JobAssignmentFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all JobAssignments
     * const jobAssignments = await prisma.jobAssignment.findMany()
     * 
     * // Get first 10 JobAssignments
     * const jobAssignments = await prisma.jobAssignment.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const jobAssignmentWithIdOnly = await prisma.jobAssignment.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends JobAssignmentFindManyArgs>(args?: SelectSubset<T, JobAssignmentFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "findMany">>

    /**
     * Create a JobAssignment.
     * @param {JobAssignmentCreateArgs} args - Arguments to create a JobAssignment.
     * @example
     * // Create one JobAssignment
     * const JobAssignment = await prisma.jobAssignment.create({
     *   data: {
     *     // ... data to create a JobAssignment
     *   }
     * })
     * 
     */
    create<T extends JobAssignmentCreateArgs>(args: SelectSubset<T, JobAssignmentCreateArgs<ExtArgs>>): Prisma__JobAssignmentClient<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "create">, never, ExtArgs>

    /**
     * Create many JobAssignments.
     * @param {JobAssignmentCreateManyArgs} args - Arguments to create many JobAssignments.
     * @example
     * // Create many JobAssignments
     * const jobAssignment = await prisma.jobAssignment.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends JobAssignmentCreateManyArgs>(args?: SelectSubset<T, JobAssignmentCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a JobAssignment.
     * @param {JobAssignmentDeleteArgs} args - Arguments to delete one JobAssignment.
     * @example
     * // Delete one JobAssignment
     * const JobAssignment = await prisma.jobAssignment.delete({
     *   where: {
     *     // ... filter to delete one JobAssignment
     *   }
     * })
     * 
     */
    delete<T extends JobAssignmentDeleteArgs>(args: SelectSubset<T, JobAssignmentDeleteArgs<ExtArgs>>): Prisma__JobAssignmentClient<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "delete">, never, ExtArgs>

    /**
     * Update one JobAssignment.
     * @param {JobAssignmentUpdateArgs} args - Arguments to update one JobAssignment.
     * @example
     * // Update one JobAssignment
     * const jobAssignment = await prisma.jobAssignment.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends JobAssignmentUpdateArgs>(args: SelectSubset<T, JobAssignmentUpdateArgs<ExtArgs>>): Prisma__JobAssignmentClient<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "update">, never, ExtArgs>

    /**
     * Delete zero or more JobAssignments.
     * @param {JobAssignmentDeleteManyArgs} args - Arguments to filter JobAssignments to delete.
     * @example
     * // Delete a few JobAssignments
     * const { count } = await prisma.jobAssignment.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends JobAssignmentDeleteManyArgs>(args?: SelectSubset<T, JobAssignmentDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more JobAssignments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {JobAssignmentUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many JobAssignments
     * const jobAssignment = await prisma.jobAssignment.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends JobAssignmentUpdateManyArgs>(args: SelectSubset<T, JobAssignmentUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one JobAssignment.
     * @param {JobAssignmentUpsertArgs} args - Arguments to update or create a JobAssignment.
     * @example
     * // Update or create a JobAssignment
     * const jobAssignment = await prisma.jobAssignment.upsert({
     *   create: {
     *     // ... data to create a JobAssignment
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the JobAssignment we want to update
     *   }
     * })
     */
    upsert<T extends JobAssignmentUpsertArgs>(args: SelectSubset<T, JobAssignmentUpsertArgs<ExtArgs>>): Prisma__JobAssignmentClient<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "upsert">, never, ExtArgs>


    /**
     * Count the number of JobAssignments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {JobAssignmentCountArgs} args - Arguments to filter JobAssignments to count.
     * @example
     * // Count the number of JobAssignments
     * const count = await prisma.jobAssignment.count({
     *   where: {
     *     // ... the filter for the JobAssignments we want to count
     *   }
     * })
    **/
    count<T extends JobAssignmentCountArgs>(
      args?: Subset<T, JobAssignmentCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], JobAssignmentCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a JobAssignment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {JobAssignmentAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends JobAssignmentAggregateArgs>(args: Subset<T, JobAssignmentAggregateArgs>): Prisma.PrismaPromise<GetJobAssignmentAggregateType<T>>

    /**
     * Group by JobAssignment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {JobAssignmentGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends JobAssignmentGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: JobAssignmentGroupByArgs['orderBy'] }
        : { orderBy?: JobAssignmentGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, JobAssignmentGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetJobAssignmentGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the JobAssignment model
   */
  readonly fields: JobAssignmentFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for JobAssignment.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__JobAssignmentClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    employee<T extends EmployeeDefaultArgs<ExtArgs> = {}>(args?: Subset<T, EmployeeDefaultArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findUniqueOrThrow"> | Null, Null, ExtArgs>
    trips<T extends JobAssignment$tripsArgs<ExtArgs> = {}>(args?: Subset<T, JobAssignment$tripsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TripPayload<ExtArgs>, T, "findMany"> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the JobAssignment model
   */ 
  interface JobAssignmentFieldRefs {
    readonly id: FieldRef<"JobAssignment", 'String'>
    readonly employeeId: FieldRef<"JobAssignment", 'String'>
    readonly description: FieldRef<"JobAssignment", 'String'>
    readonly assignedDate: FieldRef<"JobAssignment", 'DateTime'>
    readonly status: FieldRef<"JobAssignment", 'String'>
  }
    

  // Custom InputTypes
  /**
   * JobAssignment findUnique
   */
  export type JobAssignmentFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
    /**
     * Filter, which JobAssignment to fetch.
     */
    where: JobAssignmentWhereUniqueInput
  }

  /**
   * JobAssignment findUniqueOrThrow
   */
  export type JobAssignmentFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
    /**
     * Filter, which JobAssignment to fetch.
     */
    where: JobAssignmentWhereUniqueInput
  }

  /**
   * JobAssignment findFirst
   */
  export type JobAssignmentFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
    /**
     * Filter, which JobAssignment to fetch.
     */
    where?: JobAssignmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of JobAssignments to fetch.
     */
    orderBy?: JobAssignmentOrderByWithRelationInput | JobAssignmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for JobAssignments.
     */
    cursor?: JobAssignmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` JobAssignments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` JobAssignments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of JobAssignments.
     */
    distinct?: JobAssignmentScalarFieldEnum | JobAssignmentScalarFieldEnum[]
  }

  /**
   * JobAssignment findFirstOrThrow
   */
  export type JobAssignmentFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
    /**
     * Filter, which JobAssignment to fetch.
     */
    where?: JobAssignmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of JobAssignments to fetch.
     */
    orderBy?: JobAssignmentOrderByWithRelationInput | JobAssignmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for JobAssignments.
     */
    cursor?: JobAssignmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` JobAssignments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` JobAssignments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of JobAssignments.
     */
    distinct?: JobAssignmentScalarFieldEnum | JobAssignmentScalarFieldEnum[]
  }

  /**
   * JobAssignment findMany
   */
  export type JobAssignmentFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
    /**
     * Filter, which JobAssignments to fetch.
     */
    where?: JobAssignmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of JobAssignments to fetch.
     */
    orderBy?: JobAssignmentOrderByWithRelationInput | JobAssignmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing JobAssignments.
     */
    cursor?: JobAssignmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` JobAssignments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` JobAssignments.
     */
    skip?: number
    distinct?: JobAssignmentScalarFieldEnum | JobAssignmentScalarFieldEnum[]
  }

  /**
   * JobAssignment create
   */
  export type JobAssignmentCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
    /**
     * The data needed to create a JobAssignment.
     */
    data: XOR<JobAssignmentCreateInput, JobAssignmentUncheckedCreateInput>
  }

  /**
   * JobAssignment createMany
   */
  export type JobAssignmentCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many JobAssignments.
     */
    data: JobAssignmentCreateManyInput | JobAssignmentCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * JobAssignment update
   */
  export type JobAssignmentUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
    /**
     * The data needed to update a JobAssignment.
     */
    data: XOR<JobAssignmentUpdateInput, JobAssignmentUncheckedUpdateInput>
    /**
     * Choose, which JobAssignment to update.
     */
    where: JobAssignmentWhereUniqueInput
  }

  /**
   * JobAssignment updateMany
   */
  export type JobAssignmentUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update JobAssignments.
     */
    data: XOR<JobAssignmentUpdateManyMutationInput, JobAssignmentUncheckedUpdateManyInput>
    /**
     * Filter which JobAssignments to update
     */
    where?: JobAssignmentWhereInput
  }

  /**
   * JobAssignment upsert
   */
  export type JobAssignmentUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
    /**
     * The filter to search for the JobAssignment to update in case it exists.
     */
    where: JobAssignmentWhereUniqueInput
    /**
     * In case the JobAssignment found by the `where` argument doesn't exist, create a new JobAssignment with this data.
     */
    create: XOR<JobAssignmentCreateInput, JobAssignmentUncheckedCreateInput>
    /**
     * In case the JobAssignment was found with the provided `where` argument, update it with this data.
     */
    update: XOR<JobAssignmentUpdateInput, JobAssignmentUncheckedUpdateInput>
  }

  /**
   * JobAssignment delete
   */
  export type JobAssignmentDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
    /**
     * Filter which JobAssignment to delete.
     */
    where: JobAssignmentWhereUniqueInput
  }

  /**
   * JobAssignment deleteMany
   */
  export type JobAssignmentDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which JobAssignments to delete
     */
    where?: JobAssignmentWhereInput
  }

  /**
   * JobAssignment.trips
   */
  export type JobAssignment$tripsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
    where?: TripWhereInput
    orderBy?: TripOrderByWithRelationInput | TripOrderByWithRelationInput[]
    cursor?: TripWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TripScalarFieldEnum | TripScalarFieldEnum[]
  }

  /**
   * JobAssignment without action
   */
  export type JobAssignmentDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the JobAssignment
     */
    select?: JobAssignmentSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: JobAssignmentInclude<ExtArgs> | null
  }


  /**
   * Model Trip
   */

  export type AggregateTrip = {
    _count: TripCountAggregateOutputType | null
    _avg: TripAvgAggregateOutputType | null
    _sum: TripSumAggregateOutputType | null
    _min: TripMinAggregateOutputType | null
    _max: TripMaxAggregateOutputType | null
  }

  export type TripAvgAggregateOutputType = {
    distanceKM: number | null
    fuelUsedLiters: number | null
    fuelCost: number | null
  }

  export type TripSumAggregateOutputType = {
    distanceKM: number | null
    fuelUsedLiters: number | null
    fuelCost: number | null
  }

  export type TripMinAggregateOutputType = {
    id: string | null
    jobId: string | null
    distanceKM: number | null
    fuelUsedLiters: number | null
    fuelCost: number | null
  }

  export type TripMaxAggregateOutputType = {
    id: string | null
    jobId: string | null
    distanceKM: number | null
    fuelUsedLiters: number | null
    fuelCost: number | null
  }

  export type TripCountAggregateOutputType = {
    id: number
    jobId: number
    distanceKM: number
    fuelUsedLiters: number
    fuelCost: number
    _all: number
  }


  export type TripAvgAggregateInputType = {
    distanceKM?: true
    fuelUsedLiters?: true
    fuelCost?: true
  }

  export type TripSumAggregateInputType = {
    distanceKM?: true
    fuelUsedLiters?: true
    fuelCost?: true
  }

  export type TripMinAggregateInputType = {
    id?: true
    jobId?: true
    distanceKM?: true
    fuelUsedLiters?: true
    fuelCost?: true
  }

  export type TripMaxAggregateInputType = {
    id?: true
    jobId?: true
    distanceKM?: true
    fuelUsedLiters?: true
    fuelCost?: true
  }

  export type TripCountAggregateInputType = {
    id?: true
    jobId?: true
    distanceKM?: true
    fuelUsedLiters?: true
    fuelCost?: true
    _all?: true
  }

  export type TripAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Trip to aggregate.
     */
    where?: TripWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Trips to fetch.
     */
    orderBy?: TripOrderByWithRelationInput | TripOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TripWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Trips from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Trips.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Trips
    **/
    _count?: true | TripCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TripAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TripSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TripMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TripMaxAggregateInputType
  }

  export type GetTripAggregateType<T extends TripAggregateArgs> = {
        [P in keyof T & keyof AggregateTrip]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTrip[P]>
      : GetScalarType<T[P], AggregateTrip[P]>
  }




  export type TripGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TripWhereInput
    orderBy?: TripOrderByWithAggregationInput | TripOrderByWithAggregationInput[]
    by: TripScalarFieldEnum[] | TripScalarFieldEnum
    having?: TripScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TripCountAggregateInputType | true
    _avg?: TripAvgAggregateInputType
    _sum?: TripSumAggregateInputType
    _min?: TripMinAggregateInputType
    _max?: TripMaxAggregateInputType
  }

  export type TripGroupByOutputType = {
    id: string
    jobId: string
    distanceKM: number
    fuelUsedLiters: number
    fuelCost: number
    _count: TripCountAggregateOutputType | null
    _avg: TripAvgAggregateOutputType | null
    _sum: TripSumAggregateOutputType | null
    _min: TripMinAggregateOutputType | null
    _max: TripMaxAggregateOutputType | null
  }

  type GetTripGroupByPayload<T extends TripGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TripGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TripGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TripGroupByOutputType[P]>
            : GetScalarType<T[P], TripGroupByOutputType[P]>
        }
      >
    >


  export type TripSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    jobId?: boolean
    distanceKM?: boolean
    fuelUsedLiters?: boolean
    fuelCost?: boolean
    jobAssignment?: boolean | JobAssignmentDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["trip"]>


  export type TripSelectScalar = {
    id?: boolean
    jobId?: boolean
    distanceKM?: boolean
    fuelUsedLiters?: boolean
    fuelCost?: boolean
  }

  export type TripInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    jobAssignment?: boolean | JobAssignmentDefaultArgs<ExtArgs>
  }

  export type $TripPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Trip"
    objects: {
      jobAssignment: Prisma.$JobAssignmentPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      jobId: string
      distanceKM: number
      fuelUsedLiters: number
      fuelCost: number
    }, ExtArgs["result"]["trip"]>
    composites: {}
  }

  type TripGetPayload<S extends boolean | null | undefined | TripDefaultArgs> = $Result.GetResult<Prisma.$TripPayload, S>

  type TripCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<TripFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: TripCountAggregateInputType | true
    }

  export interface TripDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Trip'], meta: { name: 'Trip' } }
    /**
     * Find zero or one Trip that matches the filter.
     * @param {TripFindUniqueArgs} args - Arguments to find a Trip
     * @example
     * // Get one Trip
     * const trip = await prisma.trip.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TripFindUniqueArgs>(args: SelectSubset<T, TripFindUniqueArgs<ExtArgs>>): Prisma__TripClient<$Result.GetResult<Prisma.$TripPayload<ExtArgs>, T, "findUnique"> | null, null, ExtArgs>

    /**
     * Find one Trip that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {TripFindUniqueOrThrowArgs} args - Arguments to find a Trip
     * @example
     * // Get one Trip
     * const trip = await prisma.trip.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TripFindUniqueOrThrowArgs>(args: SelectSubset<T, TripFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TripClient<$Result.GetResult<Prisma.$TripPayload<ExtArgs>, T, "findUniqueOrThrow">, never, ExtArgs>

    /**
     * Find the first Trip that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TripFindFirstArgs} args - Arguments to find a Trip
     * @example
     * // Get one Trip
     * const trip = await prisma.trip.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TripFindFirstArgs>(args?: SelectSubset<T, TripFindFirstArgs<ExtArgs>>): Prisma__TripClient<$Result.GetResult<Prisma.$TripPayload<ExtArgs>, T, "findFirst"> | null, null, ExtArgs>

    /**
     * Find the first Trip that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TripFindFirstOrThrowArgs} args - Arguments to find a Trip
     * @example
     * // Get one Trip
     * const trip = await prisma.trip.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TripFindFirstOrThrowArgs>(args?: SelectSubset<T, TripFindFirstOrThrowArgs<ExtArgs>>): Prisma__TripClient<$Result.GetResult<Prisma.$TripPayload<ExtArgs>, T, "findFirstOrThrow">, never, ExtArgs>

    /**
     * Find zero or more Trips that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TripFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Trips
     * const trips = await prisma.trip.findMany()
     * 
     * // Get first 10 Trips
     * const trips = await prisma.trip.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const tripWithIdOnly = await prisma.trip.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TripFindManyArgs>(args?: SelectSubset<T, TripFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TripPayload<ExtArgs>, T, "findMany">>

    /**
     * Create a Trip.
     * @param {TripCreateArgs} args - Arguments to create a Trip.
     * @example
     * // Create one Trip
     * const Trip = await prisma.trip.create({
     *   data: {
     *     // ... data to create a Trip
     *   }
     * })
     * 
     */
    create<T extends TripCreateArgs>(args: SelectSubset<T, TripCreateArgs<ExtArgs>>): Prisma__TripClient<$Result.GetResult<Prisma.$TripPayload<ExtArgs>, T, "create">, never, ExtArgs>

    /**
     * Create many Trips.
     * @param {TripCreateManyArgs} args - Arguments to create many Trips.
     * @example
     * // Create many Trips
     * const trip = await prisma.trip.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TripCreateManyArgs>(args?: SelectSubset<T, TripCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Trip.
     * @param {TripDeleteArgs} args - Arguments to delete one Trip.
     * @example
     * // Delete one Trip
     * const Trip = await prisma.trip.delete({
     *   where: {
     *     // ... filter to delete one Trip
     *   }
     * })
     * 
     */
    delete<T extends TripDeleteArgs>(args: SelectSubset<T, TripDeleteArgs<ExtArgs>>): Prisma__TripClient<$Result.GetResult<Prisma.$TripPayload<ExtArgs>, T, "delete">, never, ExtArgs>

    /**
     * Update one Trip.
     * @param {TripUpdateArgs} args - Arguments to update one Trip.
     * @example
     * // Update one Trip
     * const trip = await prisma.trip.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TripUpdateArgs>(args: SelectSubset<T, TripUpdateArgs<ExtArgs>>): Prisma__TripClient<$Result.GetResult<Prisma.$TripPayload<ExtArgs>, T, "update">, never, ExtArgs>

    /**
     * Delete zero or more Trips.
     * @param {TripDeleteManyArgs} args - Arguments to filter Trips to delete.
     * @example
     * // Delete a few Trips
     * const { count } = await prisma.trip.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TripDeleteManyArgs>(args?: SelectSubset<T, TripDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Trips.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TripUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Trips
     * const trip = await prisma.trip.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TripUpdateManyArgs>(args: SelectSubset<T, TripUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Trip.
     * @param {TripUpsertArgs} args - Arguments to update or create a Trip.
     * @example
     * // Update or create a Trip
     * const trip = await prisma.trip.upsert({
     *   create: {
     *     // ... data to create a Trip
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Trip we want to update
     *   }
     * })
     */
    upsert<T extends TripUpsertArgs>(args: SelectSubset<T, TripUpsertArgs<ExtArgs>>): Prisma__TripClient<$Result.GetResult<Prisma.$TripPayload<ExtArgs>, T, "upsert">, never, ExtArgs>


    /**
     * Count the number of Trips.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TripCountArgs} args - Arguments to filter Trips to count.
     * @example
     * // Count the number of Trips
     * const count = await prisma.trip.count({
     *   where: {
     *     // ... the filter for the Trips we want to count
     *   }
     * })
    **/
    count<T extends TripCountArgs>(
      args?: Subset<T, TripCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TripCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Trip.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TripAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TripAggregateArgs>(args: Subset<T, TripAggregateArgs>): Prisma.PrismaPromise<GetTripAggregateType<T>>

    /**
     * Group by Trip.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TripGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TripGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TripGroupByArgs['orderBy'] }
        : { orderBy?: TripGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TripGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTripGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Trip model
   */
  readonly fields: TripFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Trip.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TripClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    jobAssignment<T extends JobAssignmentDefaultArgs<ExtArgs> = {}>(args?: Subset<T, JobAssignmentDefaultArgs<ExtArgs>>): Prisma__JobAssignmentClient<$Result.GetResult<Prisma.$JobAssignmentPayload<ExtArgs>, T, "findUniqueOrThrow"> | Null, Null, ExtArgs>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Trip model
   */ 
  interface TripFieldRefs {
    readonly id: FieldRef<"Trip", 'String'>
    readonly jobId: FieldRef<"Trip", 'String'>
    readonly distanceKM: FieldRef<"Trip", 'Int'>
    readonly fuelUsedLiters: FieldRef<"Trip", 'Int'>
    readonly fuelCost: FieldRef<"Trip", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * Trip findUnique
   */
  export type TripFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
    /**
     * Filter, which Trip to fetch.
     */
    where: TripWhereUniqueInput
  }

  /**
   * Trip findUniqueOrThrow
   */
  export type TripFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
    /**
     * Filter, which Trip to fetch.
     */
    where: TripWhereUniqueInput
  }

  /**
   * Trip findFirst
   */
  export type TripFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
    /**
     * Filter, which Trip to fetch.
     */
    where?: TripWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Trips to fetch.
     */
    orderBy?: TripOrderByWithRelationInput | TripOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Trips.
     */
    cursor?: TripWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Trips from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Trips.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Trips.
     */
    distinct?: TripScalarFieldEnum | TripScalarFieldEnum[]
  }

  /**
   * Trip findFirstOrThrow
   */
  export type TripFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
    /**
     * Filter, which Trip to fetch.
     */
    where?: TripWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Trips to fetch.
     */
    orderBy?: TripOrderByWithRelationInput | TripOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Trips.
     */
    cursor?: TripWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Trips from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Trips.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Trips.
     */
    distinct?: TripScalarFieldEnum | TripScalarFieldEnum[]
  }

  /**
   * Trip findMany
   */
  export type TripFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
    /**
     * Filter, which Trips to fetch.
     */
    where?: TripWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Trips to fetch.
     */
    orderBy?: TripOrderByWithRelationInput | TripOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Trips.
     */
    cursor?: TripWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Trips from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Trips.
     */
    skip?: number
    distinct?: TripScalarFieldEnum | TripScalarFieldEnum[]
  }

  /**
   * Trip create
   */
  export type TripCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
    /**
     * The data needed to create a Trip.
     */
    data: XOR<TripCreateInput, TripUncheckedCreateInput>
  }

  /**
   * Trip createMany
   */
  export type TripCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Trips.
     */
    data: TripCreateManyInput | TripCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Trip update
   */
  export type TripUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
    /**
     * The data needed to update a Trip.
     */
    data: XOR<TripUpdateInput, TripUncheckedUpdateInput>
    /**
     * Choose, which Trip to update.
     */
    where: TripWhereUniqueInput
  }

  /**
   * Trip updateMany
   */
  export type TripUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Trips.
     */
    data: XOR<TripUpdateManyMutationInput, TripUncheckedUpdateManyInput>
    /**
     * Filter which Trips to update
     */
    where?: TripWhereInput
  }

  /**
   * Trip upsert
   */
  export type TripUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
    /**
     * The filter to search for the Trip to update in case it exists.
     */
    where: TripWhereUniqueInput
    /**
     * In case the Trip found by the `where` argument doesn't exist, create a new Trip with this data.
     */
    create: XOR<TripCreateInput, TripUncheckedCreateInput>
    /**
     * In case the Trip was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TripUpdateInput, TripUncheckedUpdateInput>
  }

  /**
   * Trip delete
   */
  export type TripDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
    /**
     * Filter which Trip to delete.
     */
    where: TripWhereUniqueInput
  }

  /**
   * Trip deleteMany
   */
  export type TripDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Trips to delete
     */
    where?: TripWhereInput
  }

  /**
   * Trip without action
   */
  export type TripDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trip
     */
    select?: TripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TripInclude<ExtArgs> | null
  }


  /**
   * Model TravelCost
   */

  export type AggregateTravelCost = {
    _count: TravelCostCountAggregateOutputType | null
    _avg: TravelCostAvgAggregateOutputType | null
    _sum: TravelCostSumAggregateOutputType | null
    _min: TravelCostMinAggregateOutputType | null
    _max: TravelCostMaxAggregateOutputType | null
  }

  export type TravelCostAvgAggregateOutputType = {
    id: number | null
    minDistance: number | null
    maxDistance: number | null
    rateBaht: number | null
  }

  export type TravelCostSumAggregateOutputType = {
    id: number | null
    minDistance: number | null
    maxDistance: number | null
    rateBaht: number | null
  }

  export type TravelCostMinAggregateOutputType = {
    id: number | null
    minDistance: number | null
    maxDistance: number | null
    rateBaht: number | null
  }

  export type TravelCostMaxAggregateOutputType = {
    id: number | null
    minDistance: number | null
    maxDistance: number | null
    rateBaht: number | null
  }

  export type TravelCostCountAggregateOutputType = {
    id: number
    minDistance: number
    maxDistance: number
    rateBaht: number
    _all: number
  }


  export type TravelCostAvgAggregateInputType = {
    id?: true
    minDistance?: true
    maxDistance?: true
    rateBaht?: true
  }

  export type TravelCostSumAggregateInputType = {
    id?: true
    minDistance?: true
    maxDistance?: true
    rateBaht?: true
  }

  export type TravelCostMinAggregateInputType = {
    id?: true
    minDistance?: true
    maxDistance?: true
    rateBaht?: true
  }

  export type TravelCostMaxAggregateInputType = {
    id?: true
    minDistance?: true
    maxDistance?: true
    rateBaht?: true
  }

  export type TravelCostCountAggregateInputType = {
    id?: true
    minDistance?: true
    maxDistance?: true
    rateBaht?: true
    _all?: true
  }

  export type TravelCostAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TravelCost to aggregate.
     */
    where?: TravelCostWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TravelCosts to fetch.
     */
    orderBy?: TravelCostOrderByWithRelationInput | TravelCostOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TravelCostWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TravelCosts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TravelCosts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned TravelCosts
    **/
    _count?: true | TravelCostCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TravelCostAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TravelCostSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TravelCostMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TravelCostMaxAggregateInputType
  }

  export type GetTravelCostAggregateType<T extends TravelCostAggregateArgs> = {
        [P in keyof T & keyof AggregateTravelCost]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTravelCost[P]>
      : GetScalarType<T[P], AggregateTravelCost[P]>
  }




  export type TravelCostGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TravelCostWhereInput
    orderBy?: TravelCostOrderByWithAggregationInput | TravelCostOrderByWithAggregationInput[]
    by: TravelCostScalarFieldEnum[] | TravelCostScalarFieldEnum
    having?: TravelCostScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TravelCostCountAggregateInputType | true
    _avg?: TravelCostAvgAggregateInputType
    _sum?: TravelCostSumAggregateInputType
    _min?: TravelCostMinAggregateInputType
    _max?: TravelCostMaxAggregateInputType
  }

  export type TravelCostGroupByOutputType = {
    id: number
    minDistance: number
    maxDistance: number | null
    rateBaht: number
    _count: TravelCostCountAggregateOutputType | null
    _avg: TravelCostAvgAggregateOutputType | null
    _sum: TravelCostSumAggregateOutputType | null
    _min: TravelCostMinAggregateOutputType | null
    _max: TravelCostMaxAggregateOutputType | null
  }

  type GetTravelCostGroupByPayload<T extends TravelCostGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TravelCostGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TravelCostGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TravelCostGroupByOutputType[P]>
            : GetScalarType<T[P], TravelCostGroupByOutputType[P]>
        }
      >
    >


  export type TravelCostSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    minDistance?: boolean
    maxDistance?: boolean
    rateBaht?: boolean
  }, ExtArgs["result"]["travelCost"]>


  export type TravelCostSelectScalar = {
    id?: boolean
    minDistance?: boolean
    maxDistance?: boolean
    rateBaht?: boolean
  }


  export type $TravelCostPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "TravelCost"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      minDistance: number
      maxDistance: number | null
      rateBaht: number
    }, ExtArgs["result"]["travelCost"]>
    composites: {}
  }

  type TravelCostGetPayload<S extends boolean | null | undefined | TravelCostDefaultArgs> = $Result.GetResult<Prisma.$TravelCostPayload, S>

  type TravelCostCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<TravelCostFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: TravelCostCountAggregateInputType | true
    }

  export interface TravelCostDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['TravelCost'], meta: { name: 'TravelCost' } }
    /**
     * Find zero or one TravelCost that matches the filter.
     * @param {TravelCostFindUniqueArgs} args - Arguments to find a TravelCost
     * @example
     * // Get one TravelCost
     * const travelCost = await prisma.travelCost.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TravelCostFindUniqueArgs>(args: SelectSubset<T, TravelCostFindUniqueArgs<ExtArgs>>): Prisma__TravelCostClient<$Result.GetResult<Prisma.$TravelCostPayload<ExtArgs>, T, "findUnique"> | null, null, ExtArgs>

    /**
     * Find one TravelCost that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {TravelCostFindUniqueOrThrowArgs} args - Arguments to find a TravelCost
     * @example
     * // Get one TravelCost
     * const travelCost = await prisma.travelCost.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TravelCostFindUniqueOrThrowArgs>(args: SelectSubset<T, TravelCostFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TravelCostClient<$Result.GetResult<Prisma.$TravelCostPayload<ExtArgs>, T, "findUniqueOrThrow">, never, ExtArgs>

    /**
     * Find the first TravelCost that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TravelCostFindFirstArgs} args - Arguments to find a TravelCost
     * @example
     * // Get one TravelCost
     * const travelCost = await prisma.travelCost.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TravelCostFindFirstArgs>(args?: SelectSubset<T, TravelCostFindFirstArgs<ExtArgs>>): Prisma__TravelCostClient<$Result.GetResult<Prisma.$TravelCostPayload<ExtArgs>, T, "findFirst"> | null, null, ExtArgs>

    /**
     * Find the first TravelCost that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TravelCostFindFirstOrThrowArgs} args - Arguments to find a TravelCost
     * @example
     * // Get one TravelCost
     * const travelCost = await prisma.travelCost.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TravelCostFindFirstOrThrowArgs>(args?: SelectSubset<T, TravelCostFindFirstOrThrowArgs<ExtArgs>>): Prisma__TravelCostClient<$Result.GetResult<Prisma.$TravelCostPayload<ExtArgs>, T, "findFirstOrThrow">, never, ExtArgs>

    /**
     * Find zero or more TravelCosts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TravelCostFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all TravelCosts
     * const travelCosts = await prisma.travelCost.findMany()
     * 
     * // Get first 10 TravelCosts
     * const travelCosts = await prisma.travelCost.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const travelCostWithIdOnly = await prisma.travelCost.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TravelCostFindManyArgs>(args?: SelectSubset<T, TravelCostFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TravelCostPayload<ExtArgs>, T, "findMany">>

    /**
     * Create a TravelCost.
     * @param {TravelCostCreateArgs} args - Arguments to create a TravelCost.
     * @example
     * // Create one TravelCost
     * const TravelCost = await prisma.travelCost.create({
     *   data: {
     *     // ... data to create a TravelCost
     *   }
     * })
     * 
     */
    create<T extends TravelCostCreateArgs>(args: SelectSubset<T, TravelCostCreateArgs<ExtArgs>>): Prisma__TravelCostClient<$Result.GetResult<Prisma.$TravelCostPayload<ExtArgs>, T, "create">, never, ExtArgs>

    /**
     * Create many TravelCosts.
     * @param {TravelCostCreateManyArgs} args - Arguments to create many TravelCosts.
     * @example
     * // Create many TravelCosts
     * const travelCost = await prisma.travelCost.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TravelCostCreateManyArgs>(args?: SelectSubset<T, TravelCostCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a TravelCost.
     * @param {TravelCostDeleteArgs} args - Arguments to delete one TravelCost.
     * @example
     * // Delete one TravelCost
     * const TravelCost = await prisma.travelCost.delete({
     *   where: {
     *     // ... filter to delete one TravelCost
     *   }
     * })
     * 
     */
    delete<T extends TravelCostDeleteArgs>(args: SelectSubset<T, TravelCostDeleteArgs<ExtArgs>>): Prisma__TravelCostClient<$Result.GetResult<Prisma.$TravelCostPayload<ExtArgs>, T, "delete">, never, ExtArgs>

    /**
     * Update one TravelCost.
     * @param {TravelCostUpdateArgs} args - Arguments to update one TravelCost.
     * @example
     * // Update one TravelCost
     * const travelCost = await prisma.travelCost.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TravelCostUpdateArgs>(args: SelectSubset<T, TravelCostUpdateArgs<ExtArgs>>): Prisma__TravelCostClient<$Result.GetResult<Prisma.$TravelCostPayload<ExtArgs>, T, "update">, never, ExtArgs>

    /**
     * Delete zero or more TravelCosts.
     * @param {TravelCostDeleteManyArgs} args - Arguments to filter TravelCosts to delete.
     * @example
     * // Delete a few TravelCosts
     * const { count } = await prisma.travelCost.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TravelCostDeleteManyArgs>(args?: SelectSubset<T, TravelCostDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TravelCosts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TravelCostUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many TravelCosts
     * const travelCost = await prisma.travelCost.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TravelCostUpdateManyArgs>(args: SelectSubset<T, TravelCostUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one TravelCost.
     * @param {TravelCostUpsertArgs} args - Arguments to update or create a TravelCost.
     * @example
     * // Update or create a TravelCost
     * const travelCost = await prisma.travelCost.upsert({
     *   create: {
     *     // ... data to create a TravelCost
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the TravelCost we want to update
     *   }
     * })
     */
    upsert<T extends TravelCostUpsertArgs>(args: SelectSubset<T, TravelCostUpsertArgs<ExtArgs>>): Prisma__TravelCostClient<$Result.GetResult<Prisma.$TravelCostPayload<ExtArgs>, T, "upsert">, never, ExtArgs>


    /**
     * Count the number of TravelCosts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TravelCostCountArgs} args - Arguments to filter TravelCosts to count.
     * @example
     * // Count the number of TravelCosts
     * const count = await prisma.travelCost.count({
     *   where: {
     *     // ... the filter for the TravelCosts we want to count
     *   }
     * })
    **/
    count<T extends TravelCostCountArgs>(
      args?: Subset<T, TravelCostCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TravelCostCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a TravelCost.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TravelCostAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TravelCostAggregateArgs>(args: Subset<T, TravelCostAggregateArgs>): Prisma.PrismaPromise<GetTravelCostAggregateType<T>>

    /**
     * Group by TravelCost.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TravelCostGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TravelCostGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TravelCostGroupByArgs['orderBy'] }
        : { orderBy?: TravelCostGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TravelCostGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTravelCostGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the TravelCost model
   */
  readonly fields: TravelCostFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for TravelCost.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TravelCostClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the TravelCost model
   */ 
  interface TravelCostFieldRefs {
    readonly id: FieldRef<"TravelCost", 'Int'>
    readonly minDistance: FieldRef<"TravelCost", 'Int'>
    readonly maxDistance: FieldRef<"TravelCost", 'Int'>
    readonly rateBaht: FieldRef<"TravelCost", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * TravelCost findUnique
   */
  export type TravelCostFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TravelCost
     */
    select?: TravelCostSelect<ExtArgs> | null
    /**
     * Filter, which TravelCost to fetch.
     */
    where: TravelCostWhereUniqueInput
  }

  /**
   * TravelCost findUniqueOrThrow
   */
  export type TravelCostFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TravelCost
     */
    select?: TravelCostSelect<ExtArgs> | null
    /**
     * Filter, which TravelCost to fetch.
     */
    where: TravelCostWhereUniqueInput
  }

  /**
   * TravelCost findFirst
   */
  export type TravelCostFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TravelCost
     */
    select?: TravelCostSelect<ExtArgs> | null
    /**
     * Filter, which TravelCost to fetch.
     */
    where?: TravelCostWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TravelCosts to fetch.
     */
    orderBy?: TravelCostOrderByWithRelationInput | TravelCostOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TravelCosts.
     */
    cursor?: TravelCostWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TravelCosts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TravelCosts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TravelCosts.
     */
    distinct?: TravelCostScalarFieldEnum | TravelCostScalarFieldEnum[]
  }

  /**
   * TravelCost findFirstOrThrow
   */
  export type TravelCostFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TravelCost
     */
    select?: TravelCostSelect<ExtArgs> | null
    /**
     * Filter, which TravelCost to fetch.
     */
    where?: TravelCostWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TravelCosts to fetch.
     */
    orderBy?: TravelCostOrderByWithRelationInput | TravelCostOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TravelCosts.
     */
    cursor?: TravelCostWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TravelCosts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TravelCosts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TravelCosts.
     */
    distinct?: TravelCostScalarFieldEnum | TravelCostScalarFieldEnum[]
  }

  /**
   * TravelCost findMany
   */
  export type TravelCostFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TravelCost
     */
    select?: TravelCostSelect<ExtArgs> | null
    /**
     * Filter, which TravelCosts to fetch.
     */
    where?: TravelCostWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TravelCosts to fetch.
     */
    orderBy?: TravelCostOrderByWithRelationInput | TravelCostOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing TravelCosts.
     */
    cursor?: TravelCostWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TravelCosts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TravelCosts.
     */
    skip?: number
    distinct?: TravelCostScalarFieldEnum | TravelCostScalarFieldEnum[]
  }

  /**
   * TravelCost create
   */
  export type TravelCostCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TravelCost
     */
    select?: TravelCostSelect<ExtArgs> | null
    /**
     * The data needed to create a TravelCost.
     */
    data: XOR<TravelCostCreateInput, TravelCostUncheckedCreateInput>
  }

  /**
   * TravelCost createMany
   */
  export type TravelCostCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many TravelCosts.
     */
    data: TravelCostCreateManyInput | TravelCostCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * TravelCost update
   */
  export type TravelCostUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TravelCost
     */
    select?: TravelCostSelect<ExtArgs> | null
    /**
     * The data needed to update a TravelCost.
     */
    data: XOR<TravelCostUpdateInput, TravelCostUncheckedUpdateInput>
    /**
     * Choose, which TravelCost to update.
     */
    where: TravelCostWhereUniqueInput
  }

  /**
   * TravelCost updateMany
   */
  export type TravelCostUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update TravelCosts.
     */
    data: XOR<TravelCostUpdateManyMutationInput, TravelCostUncheckedUpdateManyInput>
    /**
     * Filter which TravelCosts to update
     */
    where?: TravelCostWhereInput
  }

  /**
   * TravelCost upsert
   */
  export type TravelCostUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TravelCost
     */
    select?: TravelCostSelect<ExtArgs> | null
    /**
     * The filter to search for the TravelCost to update in case it exists.
     */
    where: TravelCostWhereUniqueInput
    /**
     * In case the TravelCost found by the `where` argument doesn't exist, create a new TravelCost with this data.
     */
    create: XOR<TravelCostCreateInput, TravelCostUncheckedCreateInput>
    /**
     * In case the TravelCost was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TravelCostUpdateInput, TravelCostUncheckedUpdateInput>
  }

  /**
   * TravelCost delete
   */
  export type TravelCostDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TravelCost
     */
    select?: TravelCostSelect<ExtArgs> | null
    /**
     * Filter which TravelCost to delete.
     */
    where: TravelCostWhereUniqueInput
  }

  /**
   * TravelCost deleteMany
   */
  export type TravelCostDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TravelCosts to delete
     */
    where?: TravelCostWhereInput
  }

  /**
   * TravelCost without action
   */
  export type TravelCostDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TravelCost
     */
    select?: TravelCostSelect<ExtArgs> | null
  }


  /**
   * Model MonthlySummary
   */

  export type AggregateMonthlySummary = {
    _count: MonthlySummaryCountAggregateOutputType | null
    _avg: MonthlySummaryAvgAggregateOutputType | null
    _sum: MonthlySummarySumAggregateOutputType | null
    _min: MonthlySummaryMinAggregateOutputType | null
    _max: MonthlySummaryMaxAggregateOutputType | null
  }

  export type MonthlySummaryAvgAggregateOutputType = {
    id: number | null
    totalTrips: number | null
    totalFuelCost: number | null
    totalEarnings: number | null
  }

  export type MonthlySummarySumAggregateOutputType = {
    id: number | null
    totalTrips: number | null
    totalFuelCost: number | null
    totalEarnings: number | null
  }

  export type MonthlySummaryMinAggregateOutputType = {
    id: number | null
    employeeId: string | null
    month: string | null
    totalTrips: number | null
    totalFuelCost: number | null
    totalEarnings: number | null
  }

  export type MonthlySummaryMaxAggregateOutputType = {
    id: number | null
    employeeId: string | null
    month: string | null
    totalTrips: number | null
    totalFuelCost: number | null
    totalEarnings: number | null
  }

  export type MonthlySummaryCountAggregateOutputType = {
    id: number
    employeeId: number
    month: number
    totalTrips: number
    totalFuelCost: number
    totalEarnings: number
    _all: number
  }


  export type MonthlySummaryAvgAggregateInputType = {
    id?: true
    totalTrips?: true
    totalFuelCost?: true
    totalEarnings?: true
  }

  export type MonthlySummarySumAggregateInputType = {
    id?: true
    totalTrips?: true
    totalFuelCost?: true
    totalEarnings?: true
  }

  export type MonthlySummaryMinAggregateInputType = {
    id?: true
    employeeId?: true
    month?: true
    totalTrips?: true
    totalFuelCost?: true
    totalEarnings?: true
  }

  export type MonthlySummaryMaxAggregateInputType = {
    id?: true
    employeeId?: true
    month?: true
    totalTrips?: true
    totalFuelCost?: true
    totalEarnings?: true
  }

  export type MonthlySummaryCountAggregateInputType = {
    id?: true
    employeeId?: true
    month?: true
    totalTrips?: true
    totalFuelCost?: true
    totalEarnings?: true
    _all?: true
  }

  export type MonthlySummaryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MonthlySummary to aggregate.
     */
    where?: MonthlySummaryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MonthlySummaries to fetch.
     */
    orderBy?: MonthlySummaryOrderByWithRelationInput | MonthlySummaryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MonthlySummaryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MonthlySummaries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MonthlySummaries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned MonthlySummaries
    **/
    _count?: true | MonthlySummaryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MonthlySummaryAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MonthlySummarySumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MonthlySummaryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MonthlySummaryMaxAggregateInputType
  }

  export type GetMonthlySummaryAggregateType<T extends MonthlySummaryAggregateArgs> = {
        [P in keyof T & keyof AggregateMonthlySummary]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMonthlySummary[P]>
      : GetScalarType<T[P], AggregateMonthlySummary[P]>
  }




  export type MonthlySummaryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MonthlySummaryWhereInput
    orderBy?: MonthlySummaryOrderByWithAggregationInput | MonthlySummaryOrderByWithAggregationInput[]
    by: MonthlySummaryScalarFieldEnum[] | MonthlySummaryScalarFieldEnum
    having?: MonthlySummaryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MonthlySummaryCountAggregateInputType | true
    _avg?: MonthlySummaryAvgAggregateInputType
    _sum?: MonthlySummarySumAggregateInputType
    _min?: MonthlySummaryMinAggregateInputType
    _max?: MonthlySummaryMaxAggregateInputType
  }

  export type MonthlySummaryGroupByOutputType = {
    id: number
    employeeId: string
    month: string
    totalTrips: number
    totalFuelCost: number
    totalEarnings: number
    _count: MonthlySummaryCountAggregateOutputType | null
    _avg: MonthlySummaryAvgAggregateOutputType | null
    _sum: MonthlySummarySumAggregateOutputType | null
    _min: MonthlySummaryMinAggregateOutputType | null
    _max: MonthlySummaryMaxAggregateOutputType | null
  }

  type GetMonthlySummaryGroupByPayload<T extends MonthlySummaryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MonthlySummaryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MonthlySummaryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MonthlySummaryGroupByOutputType[P]>
            : GetScalarType<T[P], MonthlySummaryGroupByOutputType[P]>
        }
      >
    >


  export type MonthlySummarySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    employeeId?: boolean
    month?: boolean
    totalTrips?: boolean
    totalFuelCost?: boolean
    totalEarnings?: boolean
    employee?: boolean | EmployeeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["monthlySummary"]>


  export type MonthlySummarySelectScalar = {
    id?: boolean
    employeeId?: boolean
    month?: boolean
    totalTrips?: boolean
    totalFuelCost?: boolean
    totalEarnings?: boolean
  }

  export type MonthlySummaryInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    employee?: boolean | EmployeeDefaultArgs<ExtArgs>
  }

  export type $MonthlySummaryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "MonthlySummary"
    objects: {
      employee: Prisma.$EmployeePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      employeeId: string
      month: string
      totalTrips: number
      totalFuelCost: number
      totalEarnings: number
    }, ExtArgs["result"]["monthlySummary"]>
    composites: {}
  }

  type MonthlySummaryGetPayload<S extends boolean | null | undefined | MonthlySummaryDefaultArgs> = $Result.GetResult<Prisma.$MonthlySummaryPayload, S>

  type MonthlySummaryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<MonthlySummaryFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: MonthlySummaryCountAggregateInputType | true
    }

  export interface MonthlySummaryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['MonthlySummary'], meta: { name: 'MonthlySummary' } }
    /**
     * Find zero or one MonthlySummary that matches the filter.
     * @param {MonthlySummaryFindUniqueArgs} args - Arguments to find a MonthlySummary
     * @example
     * // Get one MonthlySummary
     * const monthlySummary = await prisma.monthlySummary.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MonthlySummaryFindUniqueArgs>(args: SelectSubset<T, MonthlySummaryFindUniqueArgs<ExtArgs>>): Prisma__MonthlySummaryClient<$Result.GetResult<Prisma.$MonthlySummaryPayload<ExtArgs>, T, "findUnique"> | null, null, ExtArgs>

    /**
     * Find one MonthlySummary that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {MonthlySummaryFindUniqueOrThrowArgs} args - Arguments to find a MonthlySummary
     * @example
     * // Get one MonthlySummary
     * const monthlySummary = await prisma.monthlySummary.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MonthlySummaryFindUniqueOrThrowArgs>(args: SelectSubset<T, MonthlySummaryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MonthlySummaryClient<$Result.GetResult<Prisma.$MonthlySummaryPayload<ExtArgs>, T, "findUniqueOrThrow">, never, ExtArgs>

    /**
     * Find the first MonthlySummary that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MonthlySummaryFindFirstArgs} args - Arguments to find a MonthlySummary
     * @example
     * // Get one MonthlySummary
     * const monthlySummary = await prisma.monthlySummary.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MonthlySummaryFindFirstArgs>(args?: SelectSubset<T, MonthlySummaryFindFirstArgs<ExtArgs>>): Prisma__MonthlySummaryClient<$Result.GetResult<Prisma.$MonthlySummaryPayload<ExtArgs>, T, "findFirst"> | null, null, ExtArgs>

    /**
     * Find the first MonthlySummary that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MonthlySummaryFindFirstOrThrowArgs} args - Arguments to find a MonthlySummary
     * @example
     * // Get one MonthlySummary
     * const monthlySummary = await prisma.monthlySummary.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MonthlySummaryFindFirstOrThrowArgs>(args?: SelectSubset<T, MonthlySummaryFindFirstOrThrowArgs<ExtArgs>>): Prisma__MonthlySummaryClient<$Result.GetResult<Prisma.$MonthlySummaryPayload<ExtArgs>, T, "findFirstOrThrow">, never, ExtArgs>

    /**
     * Find zero or more MonthlySummaries that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MonthlySummaryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all MonthlySummaries
     * const monthlySummaries = await prisma.monthlySummary.findMany()
     * 
     * // Get first 10 MonthlySummaries
     * const monthlySummaries = await prisma.monthlySummary.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const monthlySummaryWithIdOnly = await prisma.monthlySummary.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MonthlySummaryFindManyArgs>(args?: SelectSubset<T, MonthlySummaryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MonthlySummaryPayload<ExtArgs>, T, "findMany">>

    /**
     * Create a MonthlySummary.
     * @param {MonthlySummaryCreateArgs} args - Arguments to create a MonthlySummary.
     * @example
     * // Create one MonthlySummary
     * const MonthlySummary = await prisma.monthlySummary.create({
     *   data: {
     *     // ... data to create a MonthlySummary
     *   }
     * })
     * 
     */
    create<T extends MonthlySummaryCreateArgs>(args: SelectSubset<T, MonthlySummaryCreateArgs<ExtArgs>>): Prisma__MonthlySummaryClient<$Result.GetResult<Prisma.$MonthlySummaryPayload<ExtArgs>, T, "create">, never, ExtArgs>

    /**
     * Create many MonthlySummaries.
     * @param {MonthlySummaryCreateManyArgs} args - Arguments to create many MonthlySummaries.
     * @example
     * // Create many MonthlySummaries
     * const monthlySummary = await prisma.monthlySummary.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MonthlySummaryCreateManyArgs>(args?: SelectSubset<T, MonthlySummaryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a MonthlySummary.
     * @param {MonthlySummaryDeleteArgs} args - Arguments to delete one MonthlySummary.
     * @example
     * // Delete one MonthlySummary
     * const MonthlySummary = await prisma.monthlySummary.delete({
     *   where: {
     *     // ... filter to delete one MonthlySummary
     *   }
     * })
     * 
     */
    delete<T extends MonthlySummaryDeleteArgs>(args: SelectSubset<T, MonthlySummaryDeleteArgs<ExtArgs>>): Prisma__MonthlySummaryClient<$Result.GetResult<Prisma.$MonthlySummaryPayload<ExtArgs>, T, "delete">, never, ExtArgs>

    /**
     * Update one MonthlySummary.
     * @param {MonthlySummaryUpdateArgs} args - Arguments to update one MonthlySummary.
     * @example
     * // Update one MonthlySummary
     * const monthlySummary = await prisma.monthlySummary.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MonthlySummaryUpdateArgs>(args: SelectSubset<T, MonthlySummaryUpdateArgs<ExtArgs>>): Prisma__MonthlySummaryClient<$Result.GetResult<Prisma.$MonthlySummaryPayload<ExtArgs>, T, "update">, never, ExtArgs>

    /**
     * Delete zero or more MonthlySummaries.
     * @param {MonthlySummaryDeleteManyArgs} args - Arguments to filter MonthlySummaries to delete.
     * @example
     * // Delete a few MonthlySummaries
     * const { count } = await prisma.monthlySummary.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MonthlySummaryDeleteManyArgs>(args?: SelectSubset<T, MonthlySummaryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MonthlySummaries.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MonthlySummaryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many MonthlySummaries
     * const monthlySummary = await prisma.monthlySummary.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MonthlySummaryUpdateManyArgs>(args: SelectSubset<T, MonthlySummaryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one MonthlySummary.
     * @param {MonthlySummaryUpsertArgs} args - Arguments to update or create a MonthlySummary.
     * @example
     * // Update or create a MonthlySummary
     * const monthlySummary = await prisma.monthlySummary.upsert({
     *   create: {
     *     // ... data to create a MonthlySummary
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the MonthlySummary we want to update
     *   }
     * })
     */
    upsert<T extends MonthlySummaryUpsertArgs>(args: SelectSubset<T, MonthlySummaryUpsertArgs<ExtArgs>>): Prisma__MonthlySummaryClient<$Result.GetResult<Prisma.$MonthlySummaryPayload<ExtArgs>, T, "upsert">, never, ExtArgs>


    /**
     * Count the number of MonthlySummaries.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MonthlySummaryCountArgs} args - Arguments to filter MonthlySummaries to count.
     * @example
     * // Count the number of MonthlySummaries
     * const count = await prisma.monthlySummary.count({
     *   where: {
     *     // ... the filter for the MonthlySummaries we want to count
     *   }
     * })
    **/
    count<T extends MonthlySummaryCountArgs>(
      args?: Subset<T, MonthlySummaryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MonthlySummaryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a MonthlySummary.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MonthlySummaryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MonthlySummaryAggregateArgs>(args: Subset<T, MonthlySummaryAggregateArgs>): Prisma.PrismaPromise<GetMonthlySummaryAggregateType<T>>

    /**
     * Group by MonthlySummary.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MonthlySummaryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MonthlySummaryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MonthlySummaryGroupByArgs['orderBy'] }
        : { orderBy?: MonthlySummaryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MonthlySummaryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMonthlySummaryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the MonthlySummary model
   */
  readonly fields: MonthlySummaryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for MonthlySummary.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MonthlySummaryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    employee<T extends EmployeeDefaultArgs<ExtArgs> = {}>(args?: Subset<T, EmployeeDefaultArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findUniqueOrThrow"> | Null, Null, ExtArgs>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the MonthlySummary model
   */ 
  interface MonthlySummaryFieldRefs {
    readonly id: FieldRef<"MonthlySummary", 'Int'>
    readonly employeeId: FieldRef<"MonthlySummary", 'String'>
    readonly month: FieldRef<"MonthlySummary", 'String'>
    readonly totalTrips: FieldRef<"MonthlySummary", 'Int'>
    readonly totalFuelCost: FieldRef<"MonthlySummary", 'Int'>
    readonly totalEarnings: FieldRef<"MonthlySummary", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * MonthlySummary findUnique
   */
  export type MonthlySummaryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
    /**
     * Filter, which MonthlySummary to fetch.
     */
    where: MonthlySummaryWhereUniqueInput
  }

  /**
   * MonthlySummary findUniqueOrThrow
   */
  export type MonthlySummaryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
    /**
     * Filter, which MonthlySummary to fetch.
     */
    where: MonthlySummaryWhereUniqueInput
  }

  /**
   * MonthlySummary findFirst
   */
  export type MonthlySummaryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
    /**
     * Filter, which MonthlySummary to fetch.
     */
    where?: MonthlySummaryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MonthlySummaries to fetch.
     */
    orderBy?: MonthlySummaryOrderByWithRelationInput | MonthlySummaryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MonthlySummaries.
     */
    cursor?: MonthlySummaryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MonthlySummaries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MonthlySummaries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MonthlySummaries.
     */
    distinct?: MonthlySummaryScalarFieldEnum | MonthlySummaryScalarFieldEnum[]
  }

  /**
   * MonthlySummary findFirstOrThrow
   */
  export type MonthlySummaryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
    /**
     * Filter, which MonthlySummary to fetch.
     */
    where?: MonthlySummaryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MonthlySummaries to fetch.
     */
    orderBy?: MonthlySummaryOrderByWithRelationInput | MonthlySummaryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MonthlySummaries.
     */
    cursor?: MonthlySummaryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MonthlySummaries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MonthlySummaries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MonthlySummaries.
     */
    distinct?: MonthlySummaryScalarFieldEnum | MonthlySummaryScalarFieldEnum[]
  }

  /**
   * MonthlySummary findMany
   */
  export type MonthlySummaryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
    /**
     * Filter, which MonthlySummaries to fetch.
     */
    where?: MonthlySummaryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MonthlySummaries to fetch.
     */
    orderBy?: MonthlySummaryOrderByWithRelationInput | MonthlySummaryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing MonthlySummaries.
     */
    cursor?: MonthlySummaryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MonthlySummaries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MonthlySummaries.
     */
    skip?: number
    distinct?: MonthlySummaryScalarFieldEnum | MonthlySummaryScalarFieldEnum[]
  }

  /**
   * MonthlySummary create
   */
  export type MonthlySummaryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
    /**
     * The data needed to create a MonthlySummary.
     */
    data: XOR<MonthlySummaryCreateInput, MonthlySummaryUncheckedCreateInput>
  }

  /**
   * MonthlySummary createMany
   */
  export type MonthlySummaryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many MonthlySummaries.
     */
    data: MonthlySummaryCreateManyInput | MonthlySummaryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * MonthlySummary update
   */
  export type MonthlySummaryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
    /**
     * The data needed to update a MonthlySummary.
     */
    data: XOR<MonthlySummaryUpdateInput, MonthlySummaryUncheckedUpdateInput>
    /**
     * Choose, which MonthlySummary to update.
     */
    where: MonthlySummaryWhereUniqueInput
  }

  /**
   * MonthlySummary updateMany
   */
  export type MonthlySummaryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update MonthlySummaries.
     */
    data: XOR<MonthlySummaryUpdateManyMutationInput, MonthlySummaryUncheckedUpdateManyInput>
    /**
     * Filter which MonthlySummaries to update
     */
    where?: MonthlySummaryWhereInput
  }

  /**
   * MonthlySummary upsert
   */
  export type MonthlySummaryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
    /**
     * The filter to search for the MonthlySummary to update in case it exists.
     */
    where: MonthlySummaryWhereUniqueInput
    /**
     * In case the MonthlySummary found by the `where` argument doesn't exist, create a new MonthlySummary with this data.
     */
    create: XOR<MonthlySummaryCreateInput, MonthlySummaryUncheckedCreateInput>
    /**
     * In case the MonthlySummary was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MonthlySummaryUpdateInput, MonthlySummaryUncheckedUpdateInput>
  }

  /**
   * MonthlySummary delete
   */
  export type MonthlySummaryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
    /**
     * Filter which MonthlySummary to delete.
     */
    where: MonthlySummaryWhereUniqueInput
  }

  /**
   * MonthlySummary deleteMany
   */
  export type MonthlySummaryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MonthlySummaries to delete
     */
    where?: MonthlySummaryWhereInput
  }

  /**
   * MonthlySummary without action
   */
  export type MonthlySummaryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MonthlySummary
     */
    select?: MonthlySummarySelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MonthlySummaryInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const EmployeeScalarFieldEnum: {
    id: 'id',
    name: 'name',
    position: 'position',
    phone: 'phone'
  };

  export type EmployeeScalarFieldEnum = (typeof EmployeeScalarFieldEnum)[keyof typeof EmployeeScalarFieldEnum]


  export const AttendanceScalarFieldEnum: {
    id: 'id',
    employeeId: 'employeeId',
    checkIn: 'checkIn',
    checkOut: 'checkOut',
    date: 'date'
  };

  export type AttendanceScalarFieldEnum = (typeof AttendanceScalarFieldEnum)[keyof typeof AttendanceScalarFieldEnum]


  export const JobAssignmentScalarFieldEnum: {
    id: 'id',
    employeeId: 'employeeId',
    description: 'description',
    assignedDate: 'assignedDate',
    status: 'status'
  };

  export type JobAssignmentScalarFieldEnum = (typeof JobAssignmentScalarFieldEnum)[keyof typeof JobAssignmentScalarFieldEnum]


  export const TripScalarFieldEnum: {
    id: 'id',
    jobId: 'jobId',
    distanceKM: 'distanceKM',
    fuelUsedLiters: 'fuelUsedLiters',
    fuelCost: 'fuelCost'
  };

  export type TripScalarFieldEnum = (typeof TripScalarFieldEnum)[keyof typeof TripScalarFieldEnum]


  export const TravelCostScalarFieldEnum: {
    id: 'id',
    minDistance: 'minDistance',
    maxDistance: 'maxDistance',
    rateBaht: 'rateBaht'
  };

  export type TravelCostScalarFieldEnum = (typeof TravelCostScalarFieldEnum)[keyof typeof TravelCostScalarFieldEnum]


  export const MonthlySummaryScalarFieldEnum: {
    id: 'id',
    employeeId: 'employeeId',
    month: 'month',
    totalTrips: 'totalTrips',
    totalFuelCost: 'totalFuelCost',
    totalEarnings: 'totalEarnings'
  };

  export type MonthlySummaryScalarFieldEnum = (typeof MonthlySummaryScalarFieldEnum)[keyof typeof MonthlySummaryScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references 
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type EmployeeWhereInput = {
    AND?: EmployeeWhereInput | EmployeeWhereInput[]
    OR?: EmployeeWhereInput[]
    NOT?: EmployeeWhereInput | EmployeeWhereInput[]
    id?: StringFilter<"Employee"> | string
    name?: StringFilter<"Employee"> | string
    position?: StringFilter<"Employee"> | string
    phone?: StringFilter<"Employee"> | string
    attendances?: AttendanceListRelationFilter
    jobAssignments?: JobAssignmentListRelationFilter
    monthlySummaries?: MonthlySummaryListRelationFilter
  }

  export type EmployeeOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    position?: SortOrder
    phone?: SortOrder
    attendances?: AttendanceOrderByRelationAggregateInput
    jobAssignments?: JobAssignmentOrderByRelationAggregateInput
    monthlySummaries?: MonthlySummaryOrderByRelationAggregateInput
  }

  export type EmployeeWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: EmployeeWhereInput | EmployeeWhereInput[]
    OR?: EmployeeWhereInput[]
    NOT?: EmployeeWhereInput | EmployeeWhereInput[]
    name?: StringFilter<"Employee"> | string
    position?: StringFilter<"Employee"> | string
    phone?: StringFilter<"Employee"> | string
    attendances?: AttendanceListRelationFilter
    jobAssignments?: JobAssignmentListRelationFilter
    monthlySummaries?: MonthlySummaryListRelationFilter
  }, "id">

  export type EmployeeOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    position?: SortOrder
    phone?: SortOrder
    _count?: EmployeeCountOrderByAggregateInput
    _max?: EmployeeMaxOrderByAggregateInput
    _min?: EmployeeMinOrderByAggregateInput
  }

  export type EmployeeScalarWhereWithAggregatesInput = {
    AND?: EmployeeScalarWhereWithAggregatesInput | EmployeeScalarWhereWithAggregatesInput[]
    OR?: EmployeeScalarWhereWithAggregatesInput[]
    NOT?: EmployeeScalarWhereWithAggregatesInput | EmployeeScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Employee"> | string
    name?: StringWithAggregatesFilter<"Employee"> | string
    position?: StringWithAggregatesFilter<"Employee"> | string
    phone?: StringWithAggregatesFilter<"Employee"> | string
  }

  export type AttendanceWhereInput = {
    AND?: AttendanceWhereInput | AttendanceWhereInput[]
    OR?: AttendanceWhereInput[]
    NOT?: AttendanceWhereInput | AttendanceWhereInput[]
    id?: StringFilter<"Attendance"> | string
    employeeId?: StringFilter<"Attendance"> | string
    checkIn?: DateTimeFilter<"Attendance"> | Date | string
    checkOut?: DateTimeFilter<"Attendance"> | Date | string
    date?: DateTimeFilter<"Attendance"> | Date | string
    employee?: XOR<EmployeeRelationFilter, EmployeeWhereInput>
  }

  export type AttendanceOrderByWithRelationInput = {
    id?: SortOrder
    employeeId?: SortOrder
    checkIn?: SortOrder
    checkOut?: SortOrder
    date?: SortOrder
    employee?: EmployeeOrderByWithRelationInput
  }

  export type AttendanceWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: AttendanceWhereInput | AttendanceWhereInput[]
    OR?: AttendanceWhereInput[]
    NOT?: AttendanceWhereInput | AttendanceWhereInput[]
    employeeId?: StringFilter<"Attendance"> | string
    checkIn?: DateTimeFilter<"Attendance"> | Date | string
    checkOut?: DateTimeFilter<"Attendance"> | Date | string
    date?: DateTimeFilter<"Attendance"> | Date | string
    employee?: XOR<EmployeeRelationFilter, EmployeeWhereInput>
  }, "id">

  export type AttendanceOrderByWithAggregationInput = {
    id?: SortOrder
    employeeId?: SortOrder
    checkIn?: SortOrder
    checkOut?: SortOrder
    date?: SortOrder
    _count?: AttendanceCountOrderByAggregateInput
    _max?: AttendanceMaxOrderByAggregateInput
    _min?: AttendanceMinOrderByAggregateInput
  }

  export type AttendanceScalarWhereWithAggregatesInput = {
    AND?: AttendanceScalarWhereWithAggregatesInput | AttendanceScalarWhereWithAggregatesInput[]
    OR?: AttendanceScalarWhereWithAggregatesInput[]
    NOT?: AttendanceScalarWhereWithAggregatesInput | AttendanceScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Attendance"> | string
    employeeId?: StringWithAggregatesFilter<"Attendance"> | string
    checkIn?: DateTimeWithAggregatesFilter<"Attendance"> | Date | string
    checkOut?: DateTimeWithAggregatesFilter<"Attendance"> | Date | string
    date?: DateTimeWithAggregatesFilter<"Attendance"> | Date | string
  }

  export type JobAssignmentWhereInput = {
    AND?: JobAssignmentWhereInput | JobAssignmentWhereInput[]
    OR?: JobAssignmentWhereInput[]
    NOT?: JobAssignmentWhereInput | JobAssignmentWhereInput[]
    id?: StringFilter<"JobAssignment"> | string
    employeeId?: StringFilter<"JobAssignment"> | string
    description?: StringFilter<"JobAssignment"> | string
    assignedDate?: DateTimeFilter<"JobAssignment"> | Date | string
    status?: StringFilter<"JobAssignment"> | string
    employee?: XOR<EmployeeRelationFilter, EmployeeWhereInput>
    trips?: TripListRelationFilter
  }

  export type JobAssignmentOrderByWithRelationInput = {
    id?: SortOrder
    employeeId?: SortOrder
    description?: SortOrder
    assignedDate?: SortOrder
    status?: SortOrder
    employee?: EmployeeOrderByWithRelationInput
    trips?: TripOrderByRelationAggregateInput
  }

  export type JobAssignmentWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: JobAssignmentWhereInput | JobAssignmentWhereInput[]
    OR?: JobAssignmentWhereInput[]
    NOT?: JobAssignmentWhereInput | JobAssignmentWhereInput[]
    employeeId?: StringFilter<"JobAssignment"> | string
    description?: StringFilter<"JobAssignment"> | string
    assignedDate?: DateTimeFilter<"JobAssignment"> | Date | string
    status?: StringFilter<"JobAssignment"> | string
    employee?: XOR<EmployeeRelationFilter, EmployeeWhereInput>
    trips?: TripListRelationFilter
  }, "id">

  export type JobAssignmentOrderByWithAggregationInput = {
    id?: SortOrder
    employeeId?: SortOrder
    description?: SortOrder
    assignedDate?: SortOrder
    status?: SortOrder
    _count?: JobAssignmentCountOrderByAggregateInput
    _max?: JobAssignmentMaxOrderByAggregateInput
    _min?: JobAssignmentMinOrderByAggregateInput
  }

  export type JobAssignmentScalarWhereWithAggregatesInput = {
    AND?: JobAssignmentScalarWhereWithAggregatesInput | JobAssignmentScalarWhereWithAggregatesInput[]
    OR?: JobAssignmentScalarWhereWithAggregatesInput[]
    NOT?: JobAssignmentScalarWhereWithAggregatesInput | JobAssignmentScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"JobAssignment"> | string
    employeeId?: StringWithAggregatesFilter<"JobAssignment"> | string
    description?: StringWithAggregatesFilter<"JobAssignment"> | string
    assignedDate?: DateTimeWithAggregatesFilter<"JobAssignment"> | Date | string
    status?: StringWithAggregatesFilter<"JobAssignment"> | string
  }

  export type TripWhereInput = {
    AND?: TripWhereInput | TripWhereInput[]
    OR?: TripWhereInput[]
    NOT?: TripWhereInput | TripWhereInput[]
    id?: StringFilter<"Trip"> | string
    jobId?: StringFilter<"Trip"> | string
    distanceKM?: IntFilter<"Trip"> | number
    fuelUsedLiters?: IntFilter<"Trip"> | number
    fuelCost?: IntFilter<"Trip"> | number
    jobAssignment?: XOR<JobAssignmentRelationFilter, JobAssignmentWhereInput>
  }

  export type TripOrderByWithRelationInput = {
    id?: SortOrder
    jobId?: SortOrder
    distanceKM?: SortOrder
    fuelUsedLiters?: SortOrder
    fuelCost?: SortOrder
    jobAssignment?: JobAssignmentOrderByWithRelationInput
  }

  export type TripWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: TripWhereInput | TripWhereInput[]
    OR?: TripWhereInput[]
    NOT?: TripWhereInput | TripWhereInput[]
    jobId?: StringFilter<"Trip"> | string
    distanceKM?: IntFilter<"Trip"> | number
    fuelUsedLiters?: IntFilter<"Trip"> | number
    fuelCost?: IntFilter<"Trip"> | number
    jobAssignment?: XOR<JobAssignmentRelationFilter, JobAssignmentWhereInput>
  }, "id">

  export type TripOrderByWithAggregationInput = {
    id?: SortOrder
    jobId?: SortOrder
    distanceKM?: SortOrder
    fuelUsedLiters?: SortOrder
    fuelCost?: SortOrder
    _count?: TripCountOrderByAggregateInput
    _avg?: TripAvgOrderByAggregateInput
    _max?: TripMaxOrderByAggregateInput
    _min?: TripMinOrderByAggregateInput
    _sum?: TripSumOrderByAggregateInput
  }

  export type TripScalarWhereWithAggregatesInput = {
    AND?: TripScalarWhereWithAggregatesInput | TripScalarWhereWithAggregatesInput[]
    OR?: TripScalarWhereWithAggregatesInput[]
    NOT?: TripScalarWhereWithAggregatesInput | TripScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Trip"> | string
    jobId?: StringWithAggregatesFilter<"Trip"> | string
    distanceKM?: IntWithAggregatesFilter<"Trip"> | number
    fuelUsedLiters?: IntWithAggregatesFilter<"Trip"> | number
    fuelCost?: IntWithAggregatesFilter<"Trip"> | number
  }

  export type TravelCostWhereInput = {
    AND?: TravelCostWhereInput | TravelCostWhereInput[]
    OR?: TravelCostWhereInput[]
    NOT?: TravelCostWhereInput | TravelCostWhereInput[]
    id?: IntFilter<"TravelCost"> | number
    minDistance?: IntFilter<"TravelCost"> | number
    maxDistance?: IntNullableFilter<"TravelCost"> | number | null
    rateBaht?: IntFilter<"TravelCost"> | number
  }

  export type TravelCostOrderByWithRelationInput = {
    id?: SortOrder
    minDistance?: SortOrder
    maxDistance?: SortOrderInput | SortOrder
    rateBaht?: SortOrder
  }

  export type TravelCostWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: TravelCostWhereInput | TravelCostWhereInput[]
    OR?: TravelCostWhereInput[]
    NOT?: TravelCostWhereInput | TravelCostWhereInput[]
    minDistance?: IntFilter<"TravelCost"> | number
    maxDistance?: IntNullableFilter<"TravelCost"> | number | null
    rateBaht?: IntFilter<"TravelCost"> | number
  }, "id">

  export type TravelCostOrderByWithAggregationInput = {
    id?: SortOrder
    minDistance?: SortOrder
    maxDistance?: SortOrderInput | SortOrder
    rateBaht?: SortOrder
    _count?: TravelCostCountOrderByAggregateInput
    _avg?: TravelCostAvgOrderByAggregateInput
    _max?: TravelCostMaxOrderByAggregateInput
    _min?: TravelCostMinOrderByAggregateInput
    _sum?: TravelCostSumOrderByAggregateInput
  }

  export type TravelCostScalarWhereWithAggregatesInput = {
    AND?: TravelCostScalarWhereWithAggregatesInput | TravelCostScalarWhereWithAggregatesInput[]
    OR?: TravelCostScalarWhereWithAggregatesInput[]
    NOT?: TravelCostScalarWhereWithAggregatesInput | TravelCostScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"TravelCost"> | number
    minDistance?: IntWithAggregatesFilter<"TravelCost"> | number
    maxDistance?: IntNullableWithAggregatesFilter<"TravelCost"> | number | null
    rateBaht?: IntWithAggregatesFilter<"TravelCost"> | number
  }

  export type MonthlySummaryWhereInput = {
    AND?: MonthlySummaryWhereInput | MonthlySummaryWhereInput[]
    OR?: MonthlySummaryWhereInput[]
    NOT?: MonthlySummaryWhereInput | MonthlySummaryWhereInput[]
    id?: IntFilter<"MonthlySummary"> | number
    employeeId?: StringFilter<"MonthlySummary"> | string
    month?: StringFilter<"MonthlySummary"> | string
    totalTrips?: IntFilter<"MonthlySummary"> | number
    totalFuelCost?: IntFilter<"MonthlySummary"> | number
    totalEarnings?: IntFilter<"MonthlySummary"> | number
    employee?: XOR<EmployeeRelationFilter, EmployeeWhereInput>
  }

  export type MonthlySummaryOrderByWithRelationInput = {
    id?: SortOrder
    employeeId?: SortOrder
    month?: SortOrder
    totalTrips?: SortOrder
    totalFuelCost?: SortOrder
    totalEarnings?: SortOrder
    employee?: EmployeeOrderByWithRelationInput
  }

  export type MonthlySummaryWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: MonthlySummaryWhereInput | MonthlySummaryWhereInput[]
    OR?: MonthlySummaryWhereInput[]
    NOT?: MonthlySummaryWhereInput | MonthlySummaryWhereInput[]
    employeeId?: StringFilter<"MonthlySummary"> | string
    month?: StringFilter<"MonthlySummary"> | string
    totalTrips?: IntFilter<"MonthlySummary"> | number
    totalFuelCost?: IntFilter<"MonthlySummary"> | number
    totalEarnings?: IntFilter<"MonthlySummary"> | number
    employee?: XOR<EmployeeRelationFilter, EmployeeWhereInput>
  }, "id">

  export type MonthlySummaryOrderByWithAggregationInput = {
    id?: SortOrder
    employeeId?: SortOrder
    month?: SortOrder
    totalTrips?: SortOrder
    totalFuelCost?: SortOrder
    totalEarnings?: SortOrder
    _count?: MonthlySummaryCountOrderByAggregateInput
    _avg?: MonthlySummaryAvgOrderByAggregateInput
    _max?: MonthlySummaryMaxOrderByAggregateInput
    _min?: MonthlySummaryMinOrderByAggregateInput
    _sum?: MonthlySummarySumOrderByAggregateInput
  }

  export type MonthlySummaryScalarWhereWithAggregatesInput = {
    AND?: MonthlySummaryScalarWhereWithAggregatesInput | MonthlySummaryScalarWhereWithAggregatesInput[]
    OR?: MonthlySummaryScalarWhereWithAggregatesInput[]
    NOT?: MonthlySummaryScalarWhereWithAggregatesInput | MonthlySummaryScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"MonthlySummary"> | number
    employeeId?: StringWithAggregatesFilter<"MonthlySummary"> | string
    month?: StringWithAggregatesFilter<"MonthlySummary"> | string
    totalTrips?: IntWithAggregatesFilter<"MonthlySummary"> | number
    totalFuelCost?: IntWithAggregatesFilter<"MonthlySummary"> | number
    totalEarnings?: IntWithAggregatesFilter<"MonthlySummary"> | number
  }

  export type EmployeeCreateInput = {
    id: string
    name: string
    position: string
    phone: string
    attendances?: AttendanceCreateNestedManyWithoutEmployeeInput
    jobAssignments?: JobAssignmentCreateNestedManyWithoutEmployeeInput
    monthlySummaries?: MonthlySummaryCreateNestedManyWithoutEmployeeInput
  }

  export type EmployeeUncheckedCreateInput = {
    id: string
    name: string
    position: string
    phone: string
    attendances?: AttendanceUncheckedCreateNestedManyWithoutEmployeeInput
    jobAssignments?: JobAssignmentUncheckedCreateNestedManyWithoutEmployeeInput
    monthlySummaries?: MonthlySummaryUncheckedCreateNestedManyWithoutEmployeeInput
  }

  export type EmployeeUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    position?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    attendances?: AttendanceUpdateManyWithoutEmployeeNestedInput
    jobAssignments?: JobAssignmentUpdateManyWithoutEmployeeNestedInput
    monthlySummaries?: MonthlySummaryUpdateManyWithoutEmployeeNestedInput
  }

  export type EmployeeUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    position?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    attendances?: AttendanceUncheckedUpdateManyWithoutEmployeeNestedInput
    jobAssignments?: JobAssignmentUncheckedUpdateManyWithoutEmployeeNestedInput
    monthlySummaries?: MonthlySummaryUncheckedUpdateManyWithoutEmployeeNestedInput
  }

  export type EmployeeCreateManyInput = {
    id: string
    name: string
    position: string
    phone: string
  }

  export type EmployeeUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    position?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
  }

  export type EmployeeUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    position?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
  }

  export type AttendanceCreateInput = {
    id: string
    checkIn: Date | string
    checkOut: Date | string
    date: Date | string
    employee: EmployeeCreateNestedOneWithoutAttendancesInput
  }

  export type AttendanceUncheckedCreateInput = {
    id: string
    employeeId: string
    checkIn: Date | string
    checkOut: Date | string
    date: Date | string
  }

  export type AttendanceUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    checkIn?: DateTimeFieldUpdateOperationsInput | Date | string
    checkOut?: DateTimeFieldUpdateOperationsInput | Date | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    employee?: EmployeeUpdateOneRequiredWithoutAttendancesNestedInput
  }

  export type AttendanceUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    employeeId?: StringFieldUpdateOperationsInput | string
    checkIn?: DateTimeFieldUpdateOperationsInput | Date | string
    checkOut?: DateTimeFieldUpdateOperationsInput | Date | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AttendanceCreateManyInput = {
    id: string
    employeeId: string
    checkIn: Date | string
    checkOut: Date | string
    date: Date | string
  }

  export type AttendanceUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    checkIn?: DateTimeFieldUpdateOperationsInput | Date | string
    checkOut?: DateTimeFieldUpdateOperationsInput | Date | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AttendanceUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    employeeId?: StringFieldUpdateOperationsInput | string
    checkIn?: DateTimeFieldUpdateOperationsInput | Date | string
    checkOut?: DateTimeFieldUpdateOperationsInput | Date | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type JobAssignmentCreateInput = {
    id: string
    description: string
    assignedDate: Date | string
    status: string
    employee: EmployeeCreateNestedOneWithoutJobAssignmentsInput
    trips?: TripCreateNestedManyWithoutJobAssignmentInput
  }

  export type JobAssignmentUncheckedCreateInput = {
    id: string
    employeeId: string
    description: string
    assignedDate: Date | string
    status: string
    trips?: TripUncheckedCreateNestedManyWithoutJobAssignmentInput
  }

  export type JobAssignmentUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    assignedDate?: DateTimeFieldUpdateOperationsInput | Date | string
    status?: StringFieldUpdateOperationsInput | string
    employee?: EmployeeUpdateOneRequiredWithoutJobAssignmentsNestedInput
    trips?: TripUpdateManyWithoutJobAssignmentNestedInput
  }

  export type JobAssignmentUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    employeeId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    assignedDate?: DateTimeFieldUpdateOperationsInput | Date | string
    status?: StringFieldUpdateOperationsInput | string
    trips?: TripUncheckedUpdateManyWithoutJobAssignmentNestedInput
  }

  export type JobAssignmentCreateManyInput = {
    id: string
    employeeId: string
    description: string
    assignedDate: Date | string
    status: string
  }

  export type JobAssignmentUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    assignedDate?: DateTimeFieldUpdateOperationsInput | Date | string
    status?: StringFieldUpdateOperationsInput | string
  }

  export type JobAssignmentUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    employeeId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    assignedDate?: DateTimeFieldUpdateOperationsInput | Date | string
    status?: StringFieldUpdateOperationsInput | string
  }

  export type TripCreateInput = {
    id: string
    distanceKM: number
    fuelUsedLiters: number
    fuelCost: number
    jobAssignment: JobAssignmentCreateNestedOneWithoutTripsInput
  }

  export type TripUncheckedCreateInput = {
    id: string
    jobId: string
    distanceKM: number
    fuelUsedLiters: number
    fuelCost: number
  }

  export type TripUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    distanceKM?: IntFieldUpdateOperationsInput | number
    fuelUsedLiters?: IntFieldUpdateOperationsInput | number
    fuelCost?: IntFieldUpdateOperationsInput | number
    jobAssignment?: JobAssignmentUpdateOneRequiredWithoutTripsNestedInput
  }

  export type TripUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    jobId?: StringFieldUpdateOperationsInput | string
    distanceKM?: IntFieldUpdateOperationsInput | number
    fuelUsedLiters?: IntFieldUpdateOperationsInput | number
    fuelCost?: IntFieldUpdateOperationsInput | number
  }

  export type TripCreateManyInput = {
    id: string
    jobId: string
    distanceKM: number
    fuelUsedLiters: number
    fuelCost: number
  }

  export type TripUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    distanceKM?: IntFieldUpdateOperationsInput | number
    fuelUsedLiters?: IntFieldUpdateOperationsInput | number
    fuelCost?: IntFieldUpdateOperationsInput | number
  }

  export type TripUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    jobId?: StringFieldUpdateOperationsInput | string
    distanceKM?: IntFieldUpdateOperationsInput | number
    fuelUsedLiters?: IntFieldUpdateOperationsInput | number
    fuelCost?: IntFieldUpdateOperationsInput | number
  }

  export type TravelCostCreateInput = {
    minDistance: number
    maxDistance?: number | null
    rateBaht: number
  }

  export type TravelCostUncheckedCreateInput = {
    id?: number
    minDistance: number
    maxDistance?: number | null
    rateBaht: number
  }

  export type TravelCostUpdateInput = {
    minDistance?: IntFieldUpdateOperationsInput | number
    maxDistance?: NullableIntFieldUpdateOperationsInput | number | null
    rateBaht?: IntFieldUpdateOperationsInput | number
  }

  export type TravelCostUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    minDistance?: IntFieldUpdateOperationsInput | number
    maxDistance?: NullableIntFieldUpdateOperationsInput | number | null
    rateBaht?: IntFieldUpdateOperationsInput | number
  }

  export type TravelCostCreateManyInput = {
    id?: number
    minDistance: number
    maxDistance?: number | null
    rateBaht: number
  }

  export type TravelCostUpdateManyMutationInput = {
    minDistance?: IntFieldUpdateOperationsInput | number
    maxDistance?: NullableIntFieldUpdateOperationsInput | number | null
    rateBaht?: IntFieldUpdateOperationsInput | number
  }

  export type TravelCostUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    minDistance?: IntFieldUpdateOperationsInput | number
    maxDistance?: NullableIntFieldUpdateOperationsInput | number | null
    rateBaht?: IntFieldUpdateOperationsInput | number
  }

  export type MonthlySummaryCreateInput = {
    month: string
    totalTrips: number
    totalFuelCost: number
    totalEarnings: number
    employee: EmployeeCreateNestedOneWithoutMonthlySummariesInput
  }

  export type MonthlySummaryUncheckedCreateInput = {
    id?: number
    employeeId: string
    month: string
    totalTrips: number
    totalFuelCost: number
    totalEarnings: number
  }

  export type MonthlySummaryUpdateInput = {
    month?: StringFieldUpdateOperationsInput | string
    totalTrips?: IntFieldUpdateOperationsInput | number
    totalFuelCost?: IntFieldUpdateOperationsInput | number
    totalEarnings?: IntFieldUpdateOperationsInput | number
    employee?: EmployeeUpdateOneRequiredWithoutMonthlySummariesNestedInput
  }

  export type MonthlySummaryUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    employeeId?: StringFieldUpdateOperationsInput | string
    month?: StringFieldUpdateOperationsInput | string
    totalTrips?: IntFieldUpdateOperationsInput | number
    totalFuelCost?: IntFieldUpdateOperationsInput | number
    totalEarnings?: IntFieldUpdateOperationsInput | number
  }

  export type MonthlySummaryCreateManyInput = {
    id?: number
    employeeId: string
    month: string
    totalTrips: number
    totalFuelCost: number
    totalEarnings: number
  }

  export type MonthlySummaryUpdateManyMutationInput = {
    month?: StringFieldUpdateOperationsInput | string
    totalTrips?: IntFieldUpdateOperationsInput | number
    totalFuelCost?: IntFieldUpdateOperationsInput | number
    totalEarnings?: IntFieldUpdateOperationsInput | number
  }

  export type MonthlySummaryUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    employeeId?: StringFieldUpdateOperationsInput | string
    month?: StringFieldUpdateOperationsInput | string
    totalTrips?: IntFieldUpdateOperationsInput | number
    totalFuelCost?: IntFieldUpdateOperationsInput | number
    totalEarnings?: IntFieldUpdateOperationsInput | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type AttendanceListRelationFilter = {
    every?: AttendanceWhereInput
    some?: AttendanceWhereInput
    none?: AttendanceWhereInput
  }

  export type JobAssignmentListRelationFilter = {
    every?: JobAssignmentWhereInput
    some?: JobAssignmentWhereInput
    none?: JobAssignmentWhereInput
  }

  export type MonthlySummaryListRelationFilter = {
    every?: MonthlySummaryWhereInput
    some?: MonthlySummaryWhereInput
    none?: MonthlySummaryWhereInput
  }

  export type AttendanceOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type JobAssignmentOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type MonthlySummaryOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type EmployeeCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    position?: SortOrder
    phone?: SortOrder
  }

  export type EmployeeMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    position?: SortOrder
    phone?: SortOrder
  }

  export type EmployeeMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    position?: SortOrder
    phone?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type EmployeeRelationFilter = {
    is?: EmployeeWhereInput
    isNot?: EmployeeWhereInput
  }

  export type AttendanceCountOrderByAggregateInput = {
    id?: SortOrder
    employeeId?: SortOrder
    checkIn?: SortOrder
    checkOut?: SortOrder
    date?: SortOrder
  }

  export type AttendanceMaxOrderByAggregateInput = {
    id?: SortOrder
    employeeId?: SortOrder
    checkIn?: SortOrder
    checkOut?: SortOrder
    date?: SortOrder
  }

  export type AttendanceMinOrderByAggregateInput = {
    id?: SortOrder
    employeeId?: SortOrder
    checkIn?: SortOrder
    checkOut?: SortOrder
    date?: SortOrder
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type TripListRelationFilter = {
    every?: TripWhereInput
    some?: TripWhereInput
    none?: TripWhereInput
  }

  export type TripOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type JobAssignmentCountOrderByAggregateInput = {
    id?: SortOrder
    employeeId?: SortOrder
    description?: SortOrder
    assignedDate?: SortOrder
    status?: SortOrder
  }

  export type JobAssignmentMaxOrderByAggregateInput = {
    id?: SortOrder
    employeeId?: SortOrder
    description?: SortOrder
    assignedDate?: SortOrder
    status?: SortOrder
  }

  export type JobAssignmentMinOrderByAggregateInput = {
    id?: SortOrder
    employeeId?: SortOrder
    description?: SortOrder
    assignedDate?: SortOrder
    status?: SortOrder
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type JobAssignmentRelationFilter = {
    is?: JobAssignmentWhereInput
    isNot?: JobAssignmentWhereInput
  }

  export type TripCountOrderByAggregateInput = {
    id?: SortOrder
    jobId?: SortOrder
    distanceKM?: SortOrder
    fuelUsedLiters?: SortOrder
    fuelCost?: SortOrder
  }

  export type TripAvgOrderByAggregateInput = {
    distanceKM?: SortOrder
    fuelUsedLiters?: SortOrder
    fuelCost?: SortOrder
  }

  export type TripMaxOrderByAggregateInput = {
    id?: SortOrder
    jobId?: SortOrder
    distanceKM?: SortOrder
    fuelUsedLiters?: SortOrder
    fuelCost?: SortOrder
  }

  export type TripMinOrderByAggregateInput = {
    id?: SortOrder
    jobId?: SortOrder
    distanceKM?: SortOrder
    fuelUsedLiters?: SortOrder
    fuelCost?: SortOrder
  }

  export type TripSumOrderByAggregateInput = {
    distanceKM?: SortOrder
    fuelUsedLiters?: SortOrder
    fuelCost?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type TravelCostCountOrderByAggregateInput = {
    id?: SortOrder
    minDistance?: SortOrder
    maxDistance?: SortOrder
    rateBaht?: SortOrder
  }

  export type TravelCostAvgOrderByAggregateInput = {
    id?: SortOrder
    minDistance?: SortOrder
    maxDistance?: SortOrder
    rateBaht?: SortOrder
  }

  export type TravelCostMaxOrderByAggregateInput = {
    id?: SortOrder
    minDistance?: SortOrder
    maxDistance?: SortOrder
    rateBaht?: SortOrder
  }

  export type TravelCostMinOrderByAggregateInput = {
    id?: SortOrder
    minDistance?: SortOrder
    maxDistance?: SortOrder
    rateBaht?: SortOrder
  }

  export type TravelCostSumOrderByAggregateInput = {
    id?: SortOrder
    minDistance?: SortOrder
    maxDistance?: SortOrder
    rateBaht?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type MonthlySummaryCountOrderByAggregateInput = {
    id?: SortOrder
    employeeId?: SortOrder
    month?: SortOrder
    totalTrips?: SortOrder
    totalFuelCost?: SortOrder
    totalEarnings?: SortOrder
  }

  export type MonthlySummaryAvgOrderByAggregateInput = {
    id?: SortOrder
    totalTrips?: SortOrder
    totalFuelCost?: SortOrder
    totalEarnings?: SortOrder
  }

  export type MonthlySummaryMaxOrderByAggregateInput = {
    id?: SortOrder
    employeeId?: SortOrder
    month?: SortOrder
    totalTrips?: SortOrder
    totalFuelCost?: SortOrder
    totalEarnings?: SortOrder
  }

  export type MonthlySummaryMinOrderByAggregateInput = {
    id?: SortOrder
    employeeId?: SortOrder
    month?: SortOrder
    totalTrips?: SortOrder
    totalFuelCost?: SortOrder
    totalEarnings?: SortOrder
  }

  export type MonthlySummarySumOrderByAggregateInput = {
    id?: SortOrder
    totalTrips?: SortOrder
    totalFuelCost?: SortOrder
    totalEarnings?: SortOrder
  }

  export type AttendanceCreateNestedManyWithoutEmployeeInput = {
    create?: XOR<AttendanceCreateWithoutEmployeeInput, AttendanceUncheckedCreateWithoutEmployeeInput> | AttendanceCreateWithoutEmployeeInput[] | AttendanceUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: AttendanceCreateOrConnectWithoutEmployeeInput | AttendanceCreateOrConnectWithoutEmployeeInput[]
    createMany?: AttendanceCreateManyEmployeeInputEnvelope
    connect?: AttendanceWhereUniqueInput | AttendanceWhereUniqueInput[]
  }

  export type JobAssignmentCreateNestedManyWithoutEmployeeInput = {
    create?: XOR<JobAssignmentCreateWithoutEmployeeInput, JobAssignmentUncheckedCreateWithoutEmployeeInput> | JobAssignmentCreateWithoutEmployeeInput[] | JobAssignmentUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: JobAssignmentCreateOrConnectWithoutEmployeeInput | JobAssignmentCreateOrConnectWithoutEmployeeInput[]
    createMany?: JobAssignmentCreateManyEmployeeInputEnvelope
    connect?: JobAssignmentWhereUniqueInput | JobAssignmentWhereUniqueInput[]
  }

  export type MonthlySummaryCreateNestedManyWithoutEmployeeInput = {
    create?: XOR<MonthlySummaryCreateWithoutEmployeeInput, MonthlySummaryUncheckedCreateWithoutEmployeeInput> | MonthlySummaryCreateWithoutEmployeeInput[] | MonthlySummaryUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: MonthlySummaryCreateOrConnectWithoutEmployeeInput | MonthlySummaryCreateOrConnectWithoutEmployeeInput[]
    createMany?: MonthlySummaryCreateManyEmployeeInputEnvelope
    connect?: MonthlySummaryWhereUniqueInput | MonthlySummaryWhereUniqueInput[]
  }

  export type AttendanceUncheckedCreateNestedManyWithoutEmployeeInput = {
    create?: XOR<AttendanceCreateWithoutEmployeeInput, AttendanceUncheckedCreateWithoutEmployeeInput> | AttendanceCreateWithoutEmployeeInput[] | AttendanceUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: AttendanceCreateOrConnectWithoutEmployeeInput | AttendanceCreateOrConnectWithoutEmployeeInput[]
    createMany?: AttendanceCreateManyEmployeeInputEnvelope
    connect?: AttendanceWhereUniqueInput | AttendanceWhereUniqueInput[]
  }

  export type JobAssignmentUncheckedCreateNestedManyWithoutEmployeeInput = {
    create?: XOR<JobAssignmentCreateWithoutEmployeeInput, JobAssignmentUncheckedCreateWithoutEmployeeInput> | JobAssignmentCreateWithoutEmployeeInput[] | JobAssignmentUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: JobAssignmentCreateOrConnectWithoutEmployeeInput | JobAssignmentCreateOrConnectWithoutEmployeeInput[]
    createMany?: JobAssignmentCreateManyEmployeeInputEnvelope
    connect?: JobAssignmentWhereUniqueInput | JobAssignmentWhereUniqueInput[]
  }

  export type MonthlySummaryUncheckedCreateNestedManyWithoutEmployeeInput = {
    create?: XOR<MonthlySummaryCreateWithoutEmployeeInput, MonthlySummaryUncheckedCreateWithoutEmployeeInput> | MonthlySummaryCreateWithoutEmployeeInput[] | MonthlySummaryUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: MonthlySummaryCreateOrConnectWithoutEmployeeInput | MonthlySummaryCreateOrConnectWithoutEmployeeInput[]
    createMany?: MonthlySummaryCreateManyEmployeeInputEnvelope
    connect?: MonthlySummaryWhereUniqueInput | MonthlySummaryWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type AttendanceUpdateManyWithoutEmployeeNestedInput = {
    create?: XOR<AttendanceCreateWithoutEmployeeInput, AttendanceUncheckedCreateWithoutEmployeeInput> | AttendanceCreateWithoutEmployeeInput[] | AttendanceUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: AttendanceCreateOrConnectWithoutEmployeeInput | AttendanceCreateOrConnectWithoutEmployeeInput[]
    upsert?: AttendanceUpsertWithWhereUniqueWithoutEmployeeInput | AttendanceUpsertWithWhereUniqueWithoutEmployeeInput[]
    createMany?: AttendanceCreateManyEmployeeInputEnvelope
    set?: AttendanceWhereUniqueInput | AttendanceWhereUniqueInput[]
    disconnect?: AttendanceWhereUniqueInput | AttendanceWhereUniqueInput[]
    delete?: AttendanceWhereUniqueInput | AttendanceWhereUniqueInput[]
    connect?: AttendanceWhereUniqueInput | AttendanceWhereUniqueInput[]
    update?: AttendanceUpdateWithWhereUniqueWithoutEmployeeInput | AttendanceUpdateWithWhereUniqueWithoutEmployeeInput[]
    updateMany?: AttendanceUpdateManyWithWhereWithoutEmployeeInput | AttendanceUpdateManyWithWhereWithoutEmployeeInput[]
    deleteMany?: AttendanceScalarWhereInput | AttendanceScalarWhereInput[]
  }

  export type JobAssignmentUpdateManyWithoutEmployeeNestedInput = {
    create?: XOR<JobAssignmentCreateWithoutEmployeeInput, JobAssignmentUncheckedCreateWithoutEmployeeInput> | JobAssignmentCreateWithoutEmployeeInput[] | JobAssignmentUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: JobAssignmentCreateOrConnectWithoutEmployeeInput | JobAssignmentCreateOrConnectWithoutEmployeeInput[]
    upsert?: JobAssignmentUpsertWithWhereUniqueWithoutEmployeeInput | JobAssignmentUpsertWithWhereUniqueWithoutEmployeeInput[]
    createMany?: JobAssignmentCreateManyEmployeeInputEnvelope
    set?: JobAssignmentWhereUniqueInput | JobAssignmentWhereUniqueInput[]
    disconnect?: JobAssignmentWhereUniqueInput | JobAssignmentWhereUniqueInput[]
    delete?: JobAssignmentWhereUniqueInput | JobAssignmentWhereUniqueInput[]
    connect?: JobAssignmentWhereUniqueInput | JobAssignmentWhereUniqueInput[]
    update?: JobAssignmentUpdateWithWhereUniqueWithoutEmployeeInput | JobAssignmentUpdateWithWhereUniqueWithoutEmployeeInput[]
    updateMany?: JobAssignmentUpdateManyWithWhereWithoutEmployeeInput | JobAssignmentUpdateManyWithWhereWithoutEmployeeInput[]
    deleteMany?: JobAssignmentScalarWhereInput | JobAssignmentScalarWhereInput[]
  }

  export type MonthlySummaryUpdateManyWithoutEmployeeNestedInput = {
    create?: XOR<MonthlySummaryCreateWithoutEmployeeInput, MonthlySummaryUncheckedCreateWithoutEmployeeInput> | MonthlySummaryCreateWithoutEmployeeInput[] | MonthlySummaryUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: MonthlySummaryCreateOrConnectWithoutEmployeeInput | MonthlySummaryCreateOrConnectWithoutEmployeeInput[]
    upsert?: MonthlySummaryUpsertWithWhereUniqueWithoutEmployeeInput | MonthlySummaryUpsertWithWhereUniqueWithoutEmployeeInput[]
    createMany?: MonthlySummaryCreateManyEmployeeInputEnvelope
    set?: MonthlySummaryWhereUniqueInput | MonthlySummaryWhereUniqueInput[]
    disconnect?: MonthlySummaryWhereUniqueInput | MonthlySummaryWhereUniqueInput[]
    delete?: MonthlySummaryWhereUniqueInput | MonthlySummaryWhereUniqueInput[]
    connect?: MonthlySummaryWhereUniqueInput | MonthlySummaryWhereUniqueInput[]
    update?: MonthlySummaryUpdateWithWhereUniqueWithoutEmployeeInput | MonthlySummaryUpdateWithWhereUniqueWithoutEmployeeInput[]
    updateMany?: MonthlySummaryUpdateManyWithWhereWithoutEmployeeInput | MonthlySummaryUpdateManyWithWhereWithoutEmployeeInput[]
    deleteMany?: MonthlySummaryScalarWhereInput | MonthlySummaryScalarWhereInput[]
  }

  export type AttendanceUncheckedUpdateManyWithoutEmployeeNestedInput = {
    create?: XOR<AttendanceCreateWithoutEmployeeInput, AttendanceUncheckedCreateWithoutEmployeeInput> | AttendanceCreateWithoutEmployeeInput[] | AttendanceUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: AttendanceCreateOrConnectWithoutEmployeeInput | AttendanceCreateOrConnectWithoutEmployeeInput[]
    upsert?: AttendanceUpsertWithWhereUniqueWithoutEmployeeInput | AttendanceUpsertWithWhereUniqueWithoutEmployeeInput[]
    createMany?: AttendanceCreateManyEmployeeInputEnvelope
    set?: AttendanceWhereUniqueInput | AttendanceWhereUniqueInput[]
    disconnect?: AttendanceWhereUniqueInput | AttendanceWhereUniqueInput[]
    delete?: AttendanceWhereUniqueInput | AttendanceWhereUniqueInput[]
    connect?: AttendanceWhereUniqueInput | AttendanceWhereUniqueInput[]
    update?: AttendanceUpdateWithWhereUniqueWithoutEmployeeInput | AttendanceUpdateWithWhereUniqueWithoutEmployeeInput[]
    updateMany?: AttendanceUpdateManyWithWhereWithoutEmployeeInput | AttendanceUpdateManyWithWhereWithoutEmployeeInput[]
    deleteMany?: AttendanceScalarWhereInput | AttendanceScalarWhereInput[]
  }

  export type JobAssignmentUncheckedUpdateManyWithoutEmployeeNestedInput = {
    create?: XOR<JobAssignmentCreateWithoutEmployeeInput, JobAssignmentUncheckedCreateWithoutEmployeeInput> | JobAssignmentCreateWithoutEmployeeInput[] | JobAssignmentUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: JobAssignmentCreateOrConnectWithoutEmployeeInput | JobAssignmentCreateOrConnectWithoutEmployeeInput[]
    upsert?: JobAssignmentUpsertWithWhereUniqueWithoutEmployeeInput | JobAssignmentUpsertWithWhereUniqueWithoutEmployeeInput[]
    createMany?: JobAssignmentCreateManyEmployeeInputEnvelope
    set?: JobAssignmentWhereUniqueInput | JobAssignmentWhereUniqueInput[]
    disconnect?: JobAssignmentWhereUniqueInput | JobAssignmentWhereUniqueInput[]
    delete?: JobAssignmentWhereUniqueInput | JobAssignmentWhereUniqueInput[]
    connect?: JobAssignmentWhereUniqueInput | JobAssignmentWhereUniqueInput[]
    update?: JobAssignmentUpdateWithWhereUniqueWithoutEmployeeInput | JobAssignmentUpdateWithWhereUniqueWithoutEmployeeInput[]
    updateMany?: JobAssignmentUpdateManyWithWhereWithoutEmployeeInput | JobAssignmentUpdateManyWithWhereWithoutEmployeeInput[]
    deleteMany?: JobAssignmentScalarWhereInput | JobAssignmentScalarWhereInput[]
  }

  export type MonthlySummaryUncheckedUpdateManyWithoutEmployeeNestedInput = {
    create?: XOR<MonthlySummaryCreateWithoutEmployeeInput, MonthlySummaryUncheckedCreateWithoutEmployeeInput> | MonthlySummaryCreateWithoutEmployeeInput[] | MonthlySummaryUncheckedCreateWithoutEmployeeInput[]
    connectOrCreate?: MonthlySummaryCreateOrConnectWithoutEmployeeInput | MonthlySummaryCreateOrConnectWithoutEmployeeInput[]
    upsert?: MonthlySummaryUpsertWithWhereUniqueWithoutEmployeeInput | MonthlySummaryUpsertWithWhereUniqueWithoutEmployeeInput[]
    createMany?: MonthlySummaryCreateManyEmployeeInputEnvelope
    set?: MonthlySummaryWhereUniqueInput | MonthlySummaryWhereUniqueInput[]
    disconnect?: MonthlySummaryWhereUniqueInput | MonthlySummaryWhereUniqueInput[]
    delete?: MonthlySummaryWhereUniqueInput | MonthlySummaryWhereUniqueInput[]
    connect?: MonthlySummaryWhereUniqueInput | MonthlySummaryWhereUniqueInput[]
    update?: MonthlySummaryUpdateWithWhereUniqueWithoutEmployeeInput | MonthlySummaryUpdateWithWhereUniqueWithoutEmployeeInput[]
    updateMany?: MonthlySummaryUpdateManyWithWhereWithoutEmployeeInput | MonthlySummaryUpdateManyWithWhereWithoutEmployeeInput[]
    deleteMany?: MonthlySummaryScalarWhereInput | MonthlySummaryScalarWhereInput[]
  }

  export type EmployeeCreateNestedOneWithoutAttendancesInput = {
    create?: XOR<EmployeeCreateWithoutAttendancesInput, EmployeeUncheckedCreateWithoutAttendancesInput>
    connectOrCreate?: EmployeeCreateOrConnectWithoutAttendancesInput
    connect?: EmployeeWhereUniqueInput
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type EmployeeUpdateOneRequiredWithoutAttendancesNestedInput = {
    create?: XOR<EmployeeCreateWithoutAttendancesInput, EmployeeUncheckedCreateWithoutAttendancesInput>
    connectOrCreate?: EmployeeCreateOrConnectWithoutAttendancesInput
    upsert?: EmployeeUpsertWithoutAttendancesInput
    connect?: EmployeeWhereUniqueInput
    update?: XOR<XOR<EmployeeUpdateToOneWithWhereWithoutAttendancesInput, EmployeeUpdateWithoutAttendancesInput>, EmployeeUncheckedUpdateWithoutAttendancesInput>
  }

  export type EmployeeCreateNestedOneWithoutJobAssignmentsInput = {
    create?: XOR<EmployeeCreateWithoutJobAssignmentsInput, EmployeeUncheckedCreateWithoutJobAssignmentsInput>
    connectOrCreate?: EmployeeCreateOrConnectWithoutJobAssignmentsInput
    connect?: EmployeeWhereUniqueInput
  }

  export type TripCreateNestedManyWithoutJobAssignmentInput = {
    create?: XOR<TripCreateWithoutJobAssignmentInput, TripUncheckedCreateWithoutJobAssignmentInput> | TripCreateWithoutJobAssignmentInput[] | TripUncheckedCreateWithoutJobAssignmentInput[]
    connectOrCreate?: TripCreateOrConnectWithoutJobAssignmentInput | TripCreateOrConnectWithoutJobAssignmentInput[]
    createMany?: TripCreateManyJobAssignmentInputEnvelope
    connect?: TripWhereUniqueInput | TripWhereUniqueInput[]
  }

  export type TripUncheckedCreateNestedManyWithoutJobAssignmentInput = {
    create?: XOR<TripCreateWithoutJobAssignmentInput, TripUncheckedCreateWithoutJobAssignmentInput> | TripCreateWithoutJobAssignmentInput[] | TripUncheckedCreateWithoutJobAssignmentInput[]
    connectOrCreate?: TripCreateOrConnectWithoutJobAssignmentInput | TripCreateOrConnectWithoutJobAssignmentInput[]
    createMany?: TripCreateManyJobAssignmentInputEnvelope
    connect?: TripWhereUniqueInput | TripWhereUniqueInput[]
  }

  export type EmployeeUpdateOneRequiredWithoutJobAssignmentsNestedInput = {
    create?: XOR<EmployeeCreateWithoutJobAssignmentsInput, EmployeeUncheckedCreateWithoutJobAssignmentsInput>
    connectOrCreate?: EmployeeCreateOrConnectWithoutJobAssignmentsInput
    upsert?: EmployeeUpsertWithoutJobAssignmentsInput
    connect?: EmployeeWhereUniqueInput
    update?: XOR<XOR<EmployeeUpdateToOneWithWhereWithoutJobAssignmentsInput, EmployeeUpdateWithoutJobAssignmentsInput>, EmployeeUncheckedUpdateWithoutJobAssignmentsInput>
  }

  export type TripUpdateManyWithoutJobAssignmentNestedInput = {
    create?: XOR<TripCreateWithoutJobAssignmentInput, TripUncheckedCreateWithoutJobAssignmentInput> | TripCreateWithoutJobAssignmentInput[] | TripUncheckedCreateWithoutJobAssignmentInput[]
    connectOrCreate?: TripCreateOrConnectWithoutJobAssignmentInput | TripCreateOrConnectWithoutJobAssignmentInput[]
    upsert?: TripUpsertWithWhereUniqueWithoutJobAssignmentInput | TripUpsertWithWhereUniqueWithoutJobAssignmentInput[]
    createMany?: TripCreateManyJobAssignmentInputEnvelope
    set?: TripWhereUniqueInput | TripWhereUniqueInput[]
    disconnect?: TripWhereUniqueInput | TripWhereUniqueInput[]
    delete?: TripWhereUniqueInput | TripWhereUniqueInput[]
    connect?: TripWhereUniqueInput | TripWhereUniqueInput[]
    update?: TripUpdateWithWhereUniqueWithoutJobAssignmentInput | TripUpdateWithWhereUniqueWithoutJobAssignmentInput[]
    updateMany?: TripUpdateManyWithWhereWithoutJobAssignmentInput | TripUpdateManyWithWhereWithoutJobAssignmentInput[]
    deleteMany?: TripScalarWhereInput | TripScalarWhereInput[]
  }

  export type TripUncheckedUpdateManyWithoutJobAssignmentNestedInput = {
    create?: XOR<TripCreateWithoutJobAssignmentInput, TripUncheckedCreateWithoutJobAssignmentInput> | TripCreateWithoutJobAssignmentInput[] | TripUncheckedCreateWithoutJobAssignmentInput[]
    connectOrCreate?: TripCreateOrConnectWithoutJobAssignmentInput | TripCreateOrConnectWithoutJobAssignmentInput[]
    upsert?: TripUpsertWithWhereUniqueWithoutJobAssignmentInput | TripUpsertWithWhereUniqueWithoutJobAssignmentInput[]
    createMany?: TripCreateManyJobAssignmentInputEnvelope
    set?: TripWhereUniqueInput | TripWhereUniqueInput[]
    disconnect?: TripWhereUniqueInput | TripWhereUniqueInput[]
    delete?: TripWhereUniqueInput | TripWhereUniqueInput[]
    connect?: TripWhereUniqueInput | TripWhereUniqueInput[]
    update?: TripUpdateWithWhereUniqueWithoutJobAssignmentInput | TripUpdateWithWhereUniqueWithoutJobAssignmentInput[]
    updateMany?: TripUpdateManyWithWhereWithoutJobAssignmentInput | TripUpdateManyWithWhereWithoutJobAssignmentInput[]
    deleteMany?: TripScalarWhereInput | TripScalarWhereInput[]
  }

  export type JobAssignmentCreateNestedOneWithoutTripsInput = {
    create?: XOR<JobAssignmentCreateWithoutTripsInput, JobAssignmentUncheckedCreateWithoutTripsInput>
    connectOrCreate?: JobAssignmentCreateOrConnectWithoutTripsInput
    connect?: JobAssignmentWhereUniqueInput
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type JobAssignmentUpdateOneRequiredWithoutTripsNestedInput = {
    create?: XOR<JobAssignmentCreateWithoutTripsInput, JobAssignmentUncheckedCreateWithoutTripsInput>
    connectOrCreate?: JobAssignmentCreateOrConnectWithoutTripsInput
    upsert?: JobAssignmentUpsertWithoutTripsInput
    connect?: JobAssignmentWhereUniqueInput
    update?: XOR<XOR<JobAssignmentUpdateToOneWithWhereWithoutTripsInput, JobAssignmentUpdateWithoutTripsInput>, JobAssignmentUncheckedUpdateWithoutTripsInput>
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type EmployeeCreateNestedOneWithoutMonthlySummariesInput = {
    create?: XOR<EmployeeCreateWithoutMonthlySummariesInput, EmployeeUncheckedCreateWithoutMonthlySummariesInput>
    connectOrCreate?: EmployeeCreateOrConnectWithoutMonthlySummariesInput
    connect?: EmployeeWhereUniqueInput
  }

  export type EmployeeUpdateOneRequiredWithoutMonthlySummariesNestedInput = {
    create?: XOR<EmployeeCreateWithoutMonthlySummariesInput, EmployeeUncheckedCreateWithoutMonthlySummariesInput>
    connectOrCreate?: EmployeeCreateOrConnectWithoutMonthlySummariesInput
    upsert?: EmployeeUpsertWithoutMonthlySummariesInput
    connect?: EmployeeWhereUniqueInput
    update?: XOR<XOR<EmployeeUpdateToOneWithWhereWithoutMonthlySummariesInput, EmployeeUpdateWithoutMonthlySummariesInput>, EmployeeUncheckedUpdateWithoutMonthlySummariesInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type AttendanceCreateWithoutEmployeeInput = {
    id: string
    checkIn: Date | string
    checkOut: Date | string
    date: Date | string
  }

  export type AttendanceUncheckedCreateWithoutEmployeeInput = {
    id: string
    checkIn: Date | string
    checkOut: Date | string
    date: Date | string
  }

  export type AttendanceCreateOrConnectWithoutEmployeeInput = {
    where: AttendanceWhereUniqueInput
    create: XOR<AttendanceCreateWithoutEmployeeInput, AttendanceUncheckedCreateWithoutEmployeeInput>
  }

  export type AttendanceCreateManyEmployeeInputEnvelope = {
    data: AttendanceCreateManyEmployeeInput | AttendanceCreateManyEmployeeInput[]
    skipDuplicates?: boolean
  }

  export type JobAssignmentCreateWithoutEmployeeInput = {
    id: string
    description: string
    assignedDate: Date | string
    status: string
    trips?: TripCreateNestedManyWithoutJobAssignmentInput
  }

  export type JobAssignmentUncheckedCreateWithoutEmployeeInput = {
    id: string
    description: string
    assignedDate: Date | string
    status: string
    trips?: TripUncheckedCreateNestedManyWithoutJobAssignmentInput
  }

  export type JobAssignmentCreateOrConnectWithoutEmployeeInput = {
    where: JobAssignmentWhereUniqueInput
    create: XOR<JobAssignmentCreateWithoutEmployeeInput, JobAssignmentUncheckedCreateWithoutEmployeeInput>
  }

  export type JobAssignmentCreateManyEmployeeInputEnvelope = {
    data: JobAssignmentCreateManyEmployeeInput | JobAssignmentCreateManyEmployeeInput[]
    skipDuplicates?: boolean
  }

  export type MonthlySummaryCreateWithoutEmployeeInput = {
    month: string
    totalTrips: number
    totalFuelCost: number
    totalEarnings: number
  }

  export type MonthlySummaryUncheckedCreateWithoutEmployeeInput = {
    id?: number
    month: string
    totalTrips: number
    totalFuelCost: number
    totalEarnings: number
  }

  export type MonthlySummaryCreateOrConnectWithoutEmployeeInput = {
    where: MonthlySummaryWhereUniqueInput
    create: XOR<MonthlySummaryCreateWithoutEmployeeInput, MonthlySummaryUncheckedCreateWithoutEmployeeInput>
  }

  export type MonthlySummaryCreateManyEmployeeInputEnvelope = {
    data: MonthlySummaryCreateManyEmployeeInput | MonthlySummaryCreateManyEmployeeInput[]
    skipDuplicates?: boolean
  }

  export type AttendanceUpsertWithWhereUniqueWithoutEmployeeInput = {
    where: AttendanceWhereUniqueInput
    update: XOR<AttendanceUpdateWithoutEmployeeInput, AttendanceUncheckedUpdateWithoutEmployeeInput>
    create: XOR<AttendanceCreateWithoutEmployeeInput, AttendanceUncheckedCreateWithoutEmployeeInput>
  }

  export type AttendanceUpdateWithWhereUniqueWithoutEmployeeInput = {
    where: AttendanceWhereUniqueInput
    data: XOR<AttendanceUpdateWithoutEmployeeInput, AttendanceUncheckedUpdateWithoutEmployeeInput>
  }

  export type AttendanceUpdateManyWithWhereWithoutEmployeeInput = {
    where: AttendanceScalarWhereInput
    data: XOR<AttendanceUpdateManyMutationInput, AttendanceUncheckedUpdateManyWithoutEmployeeInput>
  }

  export type AttendanceScalarWhereInput = {
    AND?: AttendanceScalarWhereInput | AttendanceScalarWhereInput[]
    OR?: AttendanceScalarWhereInput[]
    NOT?: AttendanceScalarWhereInput | AttendanceScalarWhereInput[]
    id?: StringFilter<"Attendance"> | string
    employeeId?: StringFilter<"Attendance"> | string
    checkIn?: DateTimeFilter<"Attendance"> | Date | string
    checkOut?: DateTimeFilter<"Attendance"> | Date | string
    date?: DateTimeFilter<"Attendance"> | Date | string
  }

  export type JobAssignmentUpsertWithWhereUniqueWithoutEmployeeInput = {
    where: JobAssignmentWhereUniqueInput
    update: XOR<JobAssignmentUpdateWithoutEmployeeInput, JobAssignmentUncheckedUpdateWithoutEmployeeInput>
    create: XOR<JobAssignmentCreateWithoutEmployeeInput, JobAssignmentUncheckedCreateWithoutEmployeeInput>
  }

  export type JobAssignmentUpdateWithWhereUniqueWithoutEmployeeInput = {
    where: JobAssignmentWhereUniqueInput
    data: XOR<JobAssignmentUpdateWithoutEmployeeInput, JobAssignmentUncheckedUpdateWithoutEmployeeInput>
  }

  export type JobAssignmentUpdateManyWithWhereWithoutEmployeeInput = {
    where: JobAssignmentScalarWhereInput
    data: XOR<JobAssignmentUpdateManyMutationInput, JobAssignmentUncheckedUpdateManyWithoutEmployeeInput>
  }

  export type JobAssignmentScalarWhereInput = {
    AND?: JobAssignmentScalarWhereInput | JobAssignmentScalarWhereInput[]
    OR?: JobAssignmentScalarWhereInput[]
    NOT?: JobAssignmentScalarWhereInput | JobAssignmentScalarWhereInput[]
    id?: StringFilter<"JobAssignment"> | string
    employeeId?: StringFilter<"JobAssignment"> | string
    description?: StringFilter<"JobAssignment"> | string
    assignedDate?: DateTimeFilter<"JobAssignment"> | Date | string
    status?: StringFilter<"JobAssignment"> | string
  }

  export type MonthlySummaryUpsertWithWhereUniqueWithoutEmployeeInput = {
    where: MonthlySummaryWhereUniqueInput
    update: XOR<MonthlySummaryUpdateWithoutEmployeeInput, MonthlySummaryUncheckedUpdateWithoutEmployeeInput>
    create: XOR<MonthlySummaryCreateWithoutEmployeeInput, MonthlySummaryUncheckedCreateWithoutEmployeeInput>
  }

  export type MonthlySummaryUpdateWithWhereUniqueWithoutEmployeeInput = {
    where: MonthlySummaryWhereUniqueInput
    data: XOR<MonthlySummaryUpdateWithoutEmployeeInput, MonthlySummaryUncheckedUpdateWithoutEmployeeInput>
  }

  export type MonthlySummaryUpdateManyWithWhereWithoutEmployeeInput = {
    where: MonthlySummaryScalarWhereInput
    data: XOR<MonthlySummaryUpdateManyMutationInput, MonthlySummaryUncheckedUpdateManyWithoutEmployeeInput>
  }

  export type MonthlySummaryScalarWhereInput = {
    AND?: MonthlySummaryScalarWhereInput | MonthlySummaryScalarWhereInput[]
    OR?: MonthlySummaryScalarWhereInput[]
    NOT?: MonthlySummaryScalarWhereInput | MonthlySummaryScalarWhereInput[]
    id?: IntFilter<"MonthlySummary"> | number
    employeeId?: StringFilter<"MonthlySummary"> | string
    month?: StringFilter<"MonthlySummary"> | string
    totalTrips?: IntFilter<"MonthlySummary"> | number
    totalFuelCost?: IntFilter<"MonthlySummary"> | number
    totalEarnings?: IntFilter<"MonthlySummary"> | number
  }

  export type EmployeeCreateWithoutAttendancesInput = {
    id: string
    name: string
    position: string
    phone: string
    jobAssignments?: JobAssignmentCreateNestedManyWithoutEmployeeInput
    monthlySummaries?: MonthlySummaryCreateNestedManyWithoutEmployeeInput
  }

  export type EmployeeUncheckedCreateWithoutAttendancesInput = {
    id: string
    name: string
    position: string
    phone: string
    jobAssignments?: JobAssignmentUncheckedCreateNestedManyWithoutEmployeeInput
    monthlySummaries?: MonthlySummaryUncheckedCreateNestedManyWithoutEmployeeInput
  }

  export type EmployeeCreateOrConnectWithoutAttendancesInput = {
    where: EmployeeWhereUniqueInput
    create: XOR<EmployeeCreateWithoutAttendancesInput, EmployeeUncheckedCreateWithoutAttendancesInput>
  }

  export type EmployeeUpsertWithoutAttendancesInput = {
    update: XOR<EmployeeUpdateWithoutAttendancesInput, EmployeeUncheckedUpdateWithoutAttendancesInput>
    create: XOR<EmployeeCreateWithoutAttendancesInput, EmployeeUncheckedCreateWithoutAttendancesInput>
    where?: EmployeeWhereInput
  }

  export type EmployeeUpdateToOneWithWhereWithoutAttendancesInput = {
    where?: EmployeeWhereInput
    data: XOR<EmployeeUpdateWithoutAttendancesInput, EmployeeUncheckedUpdateWithoutAttendancesInput>
  }

  export type EmployeeUpdateWithoutAttendancesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    position?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    jobAssignments?: JobAssignmentUpdateManyWithoutEmployeeNestedInput
    monthlySummaries?: MonthlySummaryUpdateManyWithoutEmployeeNestedInput
  }

  export type EmployeeUncheckedUpdateWithoutAttendancesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    position?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    jobAssignments?: JobAssignmentUncheckedUpdateManyWithoutEmployeeNestedInput
    monthlySummaries?: MonthlySummaryUncheckedUpdateManyWithoutEmployeeNestedInput
  }

  export type EmployeeCreateWithoutJobAssignmentsInput = {
    id: string
    name: string
    position: string
    phone: string
    attendances?: AttendanceCreateNestedManyWithoutEmployeeInput
    monthlySummaries?: MonthlySummaryCreateNestedManyWithoutEmployeeInput
  }

  export type EmployeeUncheckedCreateWithoutJobAssignmentsInput = {
    id: string
    name: string
    position: string
    phone: string
    attendances?: AttendanceUncheckedCreateNestedManyWithoutEmployeeInput
    monthlySummaries?: MonthlySummaryUncheckedCreateNestedManyWithoutEmployeeInput
  }

  export type EmployeeCreateOrConnectWithoutJobAssignmentsInput = {
    where: EmployeeWhereUniqueInput
    create: XOR<EmployeeCreateWithoutJobAssignmentsInput, EmployeeUncheckedCreateWithoutJobAssignmentsInput>
  }

  export type TripCreateWithoutJobAssignmentInput = {
    id: string
    distanceKM: number
    fuelUsedLiters: number
    fuelCost: number
  }

  export type TripUncheckedCreateWithoutJobAssignmentInput = {
    id: string
    distanceKM: number
    fuelUsedLiters: number
    fuelCost: number
  }

  export type TripCreateOrConnectWithoutJobAssignmentInput = {
    where: TripWhereUniqueInput
    create: XOR<TripCreateWithoutJobAssignmentInput, TripUncheckedCreateWithoutJobAssignmentInput>
  }

  export type TripCreateManyJobAssignmentInputEnvelope = {
    data: TripCreateManyJobAssignmentInput | TripCreateManyJobAssignmentInput[]
    skipDuplicates?: boolean
  }

  export type EmployeeUpsertWithoutJobAssignmentsInput = {
    update: XOR<EmployeeUpdateWithoutJobAssignmentsInput, EmployeeUncheckedUpdateWithoutJobAssignmentsInput>
    create: XOR<EmployeeCreateWithoutJobAssignmentsInput, EmployeeUncheckedCreateWithoutJobAssignmentsInput>
    where?: EmployeeWhereInput
  }

  export type EmployeeUpdateToOneWithWhereWithoutJobAssignmentsInput = {
    where?: EmployeeWhereInput
    data: XOR<EmployeeUpdateWithoutJobAssignmentsInput, EmployeeUncheckedUpdateWithoutJobAssignmentsInput>
  }

  export type EmployeeUpdateWithoutJobAssignmentsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    position?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    attendances?: AttendanceUpdateManyWithoutEmployeeNestedInput
    monthlySummaries?: MonthlySummaryUpdateManyWithoutEmployeeNestedInput
  }

  export type EmployeeUncheckedUpdateWithoutJobAssignmentsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    position?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    attendances?: AttendanceUncheckedUpdateManyWithoutEmployeeNestedInput
    monthlySummaries?: MonthlySummaryUncheckedUpdateManyWithoutEmployeeNestedInput
  }

  export type TripUpsertWithWhereUniqueWithoutJobAssignmentInput = {
    where: TripWhereUniqueInput
    update: XOR<TripUpdateWithoutJobAssignmentInput, TripUncheckedUpdateWithoutJobAssignmentInput>
    create: XOR<TripCreateWithoutJobAssignmentInput, TripUncheckedCreateWithoutJobAssignmentInput>
  }

  export type TripUpdateWithWhereUniqueWithoutJobAssignmentInput = {
    where: TripWhereUniqueInput
    data: XOR<TripUpdateWithoutJobAssignmentInput, TripUncheckedUpdateWithoutJobAssignmentInput>
  }

  export type TripUpdateManyWithWhereWithoutJobAssignmentInput = {
    where: TripScalarWhereInput
    data: XOR<TripUpdateManyMutationInput, TripUncheckedUpdateManyWithoutJobAssignmentInput>
  }

  export type TripScalarWhereInput = {
    AND?: TripScalarWhereInput | TripScalarWhereInput[]
    OR?: TripScalarWhereInput[]
    NOT?: TripScalarWhereInput | TripScalarWhereInput[]
    id?: StringFilter<"Trip"> | string
    jobId?: StringFilter<"Trip"> | string
    distanceKM?: IntFilter<"Trip"> | number
    fuelUsedLiters?: IntFilter<"Trip"> | number
    fuelCost?: IntFilter<"Trip"> | number
  }

  export type JobAssignmentCreateWithoutTripsInput = {
    id: string
    description: string
    assignedDate: Date | string
    status: string
    employee: EmployeeCreateNestedOneWithoutJobAssignmentsInput
  }

  export type JobAssignmentUncheckedCreateWithoutTripsInput = {
    id: string
    employeeId: string
    description: string
    assignedDate: Date | string
    status: string
  }

  export type JobAssignmentCreateOrConnectWithoutTripsInput = {
    where: JobAssignmentWhereUniqueInput
    create: XOR<JobAssignmentCreateWithoutTripsInput, JobAssignmentUncheckedCreateWithoutTripsInput>
  }

  export type JobAssignmentUpsertWithoutTripsInput = {
    update: XOR<JobAssignmentUpdateWithoutTripsInput, JobAssignmentUncheckedUpdateWithoutTripsInput>
    create: XOR<JobAssignmentCreateWithoutTripsInput, JobAssignmentUncheckedCreateWithoutTripsInput>
    where?: JobAssignmentWhereInput
  }

  export type JobAssignmentUpdateToOneWithWhereWithoutTripsInput = {
    where?: JobAssignmentWhereInput
    data: XOR<JobAssignmentUpdateWithoutTripsInput, JobAssignmentUncheckedUpdateWithoutTripsInput>
  }

  export type JobAssignmentUpdateWithoutTripsInput = {
    id?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    assignedDate?: DateTimeFieldUpdateOperationsInput | Date | string
    status?: StringFieldUpdateOperationsInput | string
    employee?: EmployeeUpdateOneRequiredWithoutJobAssignmentsNestedInput
  }

  export type JobAssignmentUncheckedUpdateWithoutTripsInput = {
    id?: StringFieldUpdateOperationsInput | string
    employeeId?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    assignedDate?: DateTimeFieldUpdateOperationsInput | Date | string
    status?: StringFieldUpdateOperationsInput | string
  }

  export type EmployeeCreateWithoutMonthlySummariesInput = {
    id: string
    name: string
    position: string
    phone: string
    attendances?: AttendanceCreateNestedManyWithoutEmployeeInput
    jobAssignments?: JobAssignmentCreateNestedManyWithoutEmployeeInput
  }

  export type EmployeeUncheckedCreateWithoutMonthlySummariesInput = {
    id: string
    name: string
    position: string
    phone: string
    attendances?: AttendanceUncheckedCreateNestedManyWithoutEmployeeInput
    jobAssignments?: JobAssignmentUncheckedCreateNestedManyWithoutEmployeeInput
  }

  export type EmployeeCreateOrConnectWithoutMonthlySummariesInput = {
    where: EmployeeWhereUniqueInput
    create: XOR<EmployeeCreateWithoutMonthlySummariesInput, EmployeeUncheckedCreateWithoutMonthlySummariesInput>
  }

  export type EmployeeUpsertWithoutMonthlySummariesInput = {
    update: XOR<EmployeeUpdateWithoutMonthlySummariesInput, EmployeeUncheckedUpdateWithoutMonthlySummariesInput>
    create: XOR<EmployeeCreateWithoutMonthlySummariesInput, EmployeeUncheckedCreateWithoutMonthlySummariesInput>
    where?: EmployeeWhereInput
  }

  export type EmployeeUpdateToOneWithWhereWithoutMonthlySummariesInput = {
    where?: EmployeeWhereInput
    data: XOR<EmployeeUpdateWithoutMonthlySummariesInput, EmployeeUncheckedUpdateWithoutMonthlySummariesInput>
  }

  export type EmployeeUpdateWithoutMonthlySummariesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    position?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    attendances?: AttendanceUpdateManyWithoutEmployeeNestedInput
    jobAssignments?: JobAssignmentUpdateManyWithoutEmployeeNestedInput
  }

  export type EmployeeUncheckedUpdateWithoutMonthlySummariesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    position?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    attendances?: AttendanceUncheckedUpdateManyWithoutEmployeeNestedInput
    jobAssignments?: JobAssignmentUncheckedUpdateManyWithoutEmployeeNestedInput
  }

  export type AttendanceCreateManyEmployeeInput = {
    id: string
    checkIn: Date | string
    checkOut: Date | string
    date: Date | string
  }

  export type JobAssignmentCreateManyEmployeeInput = {
    id: string
    description: string
    assignedDate: Date | string
    status: string
  }

  export type MonthlySummaryCreateManyEmployeeInput = {
    id?: number
    month: string
    totalTrips: number
    totalFuelCost: number
    totalEarnings: number
  }

  export type AttendanceUpdateWithoutEmployeeInput = {
    id?: StringFieldUpdateOperationsInput | string
    checkIn?: DateTimeFieldUpdateOperationsInput | Date | string
    checkOut?: DateTimeFieldUpdateOperationsInput | Date | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AttendanceUncheckedUpdateWithoutEmployeeInput = {
    id?: StringFieldUpdateOperationsInput | string
    checkIn?: DateTimeFieldUpdateOperationsInput | Date | string
    checkOut?: DateTimeFieldUpdateOperationsInput | Date | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AttendanceUncheckedUpdateManyWithoutEmployeeInput = {
    id?: StringFieldUpdateOperationsInput | string
    checkIn?: DateTimeFieldUpdateOperationsInput | Date | string
    checkOut?: DateTimeFieldUpdateOperationsInput | Date | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type JobAssignmentUpdateWithoutEmployeeInput = {
    id?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    assignedDate?: DateTimeFieldUpdateOperationsInput | Date | string
    status?: StringFieldUpdateOperationsInput | string
    trips?: TripUpdateManyWithoutJobAssignmentNestedInput
  }

  export type JobAssignmentUncheckedUpdateWithoutEmployeeInput = {
    id?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    assignedDate?: DateTimeFieldUpdateOperationsInput | Date | string
    status?: StringFieldUpdateOperationsInput | string
    trips?: TripUncheckedUpdateManyWithoutJobAssignmentNestedInput
  }

  export type JobAssignmentUncheckedUpdateManyWithoutEmployeeInput = {
    id?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    assignedDate?: DateTimeFieldUpdateOperationsInput | Date | string
    status?: StringFieldUpdateOperationsInput | string
  }

  export type MonthlySummaryUpdateWithoutEmployeeInput = {
    month?: StringFieldUpdateOperationsInput | string
    totalTrips?: IntFieldUpdateOperationsInput | number
    totalFuelCost?: IntFieldUpdateOperationsInput | number
    totalEarnings?: IntFieldUpdateOperationsInput | number
  }

  export type MonthlySummaryUncheckedUpdateWithoutEmployeeInput = {
    id?: IntFieldUpdateOperationsInput | number
    month?: StringFieldUpdateOperationsInput | string
    totalTrips?: IntFieldUpdateOperationsInput | number
    totalFuelCost?: IntFieldUpdateOperationsInput | number
    totalEarnings?: IntFieldUpdateOperationsInput | number
  }

  export type MonthlySummaryUncheckedUpdateManyWithoutEmployeeInput = {
    id?: IntFieldUpdateOperationsInput | number
    month?: StringFieldUpdateOperationsInput | string
    totalTrips?: IntFieldUpdateOperationsInput | number
    totalFuelCost?: IntFieldUpdateOperationsInput | number
    totalEarnings?: IntFieldUpdateOperationsInput | number
  }

  export type TripCreateManyJobAssignmentInput = {
    id: string
    distanceKM: number
    fuelUsedLiters: number
    fuelCost: number
  }

  export type TripUpdateWithoutJobAssignmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    distanceKM?: IntFieldUpdateOperationsInput | number
    fuelUsedLiters?: IntFieldUpdateOperationsInput | number
    fuelCost?: IntFieldUpdateOperationsInput | number
  }

  export type TripUncheckedUpdateWithoutJobAssignmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    distanceKM?: IntFieldUpdateOperationsInput | number
    fuelUsedLiters?: IntFieldUpdateOperationsInput | number
    fuelCost?: IntFieldUpdateOperationsInput | number
  }

  export type TripUncheckedUpdateManyWithoutJobAssignmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    distanceKM?: IntFieldUpdateOperationsInput | number
    fuelUsedLiters?: IntFieldUpdateOperationsInput | number
    fuelCost?: IntFieldUpdateOperationsInput | number
  }



  /**
   * Aliases for legacy arg types
   */
    /**
     * @deprecated Use EmployeeCountOutputTypeDefaultArgs instead
     */
    export type EmployeeCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = EmployeeCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use JobAssignmentCountOutputTypeDefaultArgs instead
     */
    export type JobAssignmentCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = JobAssignmentCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use EmployeeDefaultArgs instead
     */
    export type EmployeeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = EmployeeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use AttendanceDefaultArgs instead
     */
    export type AttendanceArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = AttendanceDefaultArgs<ExtArgs>
    /**
     * @deprecated Use JobAssignmentDefaultArgs instead
     */
    export type JobAssignmentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = JobAssignmentDefaultArgs<ExtArgs>
    /**
     * @deprecated Use TripDefaultArgs instead
     */
    export type TripArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = TripDefaultArgs<ExtArgs>
    /**
     * @deprecated Use TravelCostDefaultArgs instead
     */
    export type TravelCostArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = TravelCostDefaultArgs<ExtArgs>
    /**
     * @deprecated Use MonthlySummaryDefaultArgs instead
     */
    export type MonthlySummaryArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = MonthlySummaryDefaultArgs<ExtArgs>

  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}